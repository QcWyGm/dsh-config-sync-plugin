# dsh-config-sync-plugin
中文 | [English](README.en.md)

DSH 插件：左侧栏多一行「配置同步」，点开是整页体检面板；「设置 → 通用」另有一行摘要。插件**只做体检 + 备命令**，同步动作在客户端退出后由 `runtime\sync.ps1` 执行（自动同步那一路会自己拉起客户端）。

![panel](docs/panel-1.png)

面板与宿主文案跟客户端语言走（`zh-*` → 中文，其余 → 英文），没有面板内切换开关。

---

## 安装

插件包名是 **`dsh-config-sync-plugin`**（npm 上的 `dsh-config-sync` 是同名他人项目，不是本插件）。三种装法：

| 方式 | 命令 / 入口 | 说明 |
|---|---|---|
| npm | `npm i dsh-config-sync-plugin` | 适合把它当依赖管理，或在 profile 的 `package.json` 里写 `"dsh-config-sync-plugin": "^0.3.89"` 后 `pnpm i`；包名与 `cordis.patch.yml` 里注册的名字、插件目录 `dsh-config-sync-plugin-<ver>` 一致 |
| 插件市场 | 客户端「插件市场 → 发现」搜「配置同步」 | 走 `market-index.json` 登记的 git 提交，版本与 README 对齐 |
| 离线 tgz | `releases\dsh-config-sync-plugin-<ver>.tgz` | GitHub Release 附件，适合内网机器；面板「更新」按钮下载的也是它 |

装好后插件目录是 `<客户端根>\dsh-config-sync-plugin-<ver>`，`appRoot` 留空时由插件位置反推客户端根，不用手填。

---

## 从零开始：让第二台机器跑起来

全程两条命令，源机器推一次、目标机器拉一次。下面是从零实测走通的完整顺序（2026-11-14，隔离环境两台假机 + 本地裸库，未碰主力机）。

```
源机器 A                          远端（Gitee / GitHub / 自建）        目标机器 B
─────────────────────────────     ─────────────────────────────    ─────────────────────────────
1 装插件（tgz 或市场）                                                1 装「同版本」DSH 客户端
2 面板里填 本机仓库 + 云端地址                                        2 启动一次，让它生成 profiles\desktop
3 首次推送 = 初始化推送          ──►  仓库骨架 + 全部配置  ──►        3 装插件，面板里填本机仓库 + 同一云端地址
   （自动写 6 个执行体 + 会话/工作区）                                  4 首次拉取（先体检，会覆盖本机配置）
                                                                     5 客户端起来，工作区与会话都在
```

### 前置条件（缺一项就会卡住，实测全踩过）

| 项 | 要求 | 不满足时的表现 |
|---|---|---|
| 客户端版本 | 0.4.10 起**无需同版本**：版本不同只提示、不阻断拉取（实验性 bundle 仍会剔除） | 面板/日志提示 `版本不一致`，配置照常同步 |
| 目标机器 `.dsh` | 至少启动过一次客户端，存在 `profiles\<profile>` | `[X] 目标 profile 不存在（本机还没装过 DSH？）` → 拉取直接退出 |
| Node / Electron 执行器 | 客户端自带（`<AppRoot>\node.exe` 或 `DeepSeek Harness.exe`） | `本机没有可用的内置运行时`，会话 cwd 无法改写，**会话列表会是空的** |
| 仓库骨架 | 由源机器首次推送自动写入 | 仓库里只有 `settings\`、没有 `apply.ps1` → 目标机器跑不起来，必须重新初始化推送 |
| git | 两端都装（`git.exe` 在 PATH 或常见位置） | `找不到 git.exe` |

### 源机器 A：首次推送（初始化推送）

面板 → 「本机仓库」填一个**空目录或已有仓库** → 「云端仓库」填远端地址 → 点「初始化推送」（两边都空时按钮就叫这个）。

它会依次做：`git init` → 补 `origin` → **把插件 runtime 的 6 个执行体（`apply.ps1` / `capture.ps1` / `sync.ps1` / `restore.ps1` / `post-exit.ps1` / `dsh-sync-common.ps1`）+ `tools\fix-session-cwd.mjs` 拷进仓库根** → 写 `profile\host-contract.json`（本机客户端版本）→ `capture` 抓配置 → 提交 → `push -u origin main`。

命令行等价（隔离实测用的就是这条）：

```powershell
pwsh -File runtime\sync.ps1 push `
  -RepoRoot  <仓库目录> -DshHome <~\.dsh> -AppRoot <客户端根> `
  -WorkspaceHome <工作区根> -ProfileName desktop -SkipInstall -Force
```

隔离环境首次推送的真实产物（15 个文件、commit `3fa3780`）：

```
apply.ps1  capture.ps1  dsh-sync-common.ps1  post-exit.ps1  restore.ps1  sync.ps1  tools/fix-session-cwd.mjs
profile/package.json  profile/cordis.patch.yml  profile/host-contract.json
settings/dsh-workspaces.json
workspace/workspace-registry.json  workspace/default-workspace/notes.md
conversations/session-index.json   conversations/session_projcache/s1.json
```

### 目标机器 B：首次拉取

1. 装**同版本**客户端，**启动一次**（只为生成 `profiles\desktop`，可以马上关掉）。
2. 装插件，面板里填「本机仓库」（指向一个空目录即可）与「云端仓库」（同一个远端地址）。
3. 点「拉取」。手机界面会先列出「本机领先几个提交 / 几项未提交」，确认才动手（它会用仓库版本覆盖本机配置）。
4. 起来后检查三件事：工作区列表有、点开历史会话能回到原工作区、插件页依赖齐全。

命令行等价：

```powershell
pwsh -File runtime\sync.ps1 pull `
  -RepoRoot <仓库目录> -DshHome <~\.dsh> -AppRoot <客户端根> `
  -WorkspaceHome <工作区根> -ProfileName desktop -SkipInstall -Force
```

`-SkipInstall` 跳过 `pnpm install`（隔离/离线场景必须加，否则会尝试联网装依赖）；`-Force` 用来跳过「检测到 DSH 在运行」的保护（真机请先完全退出客户端，别用 `-Force`）。

隔离环境首次拉取的真实输出（`pull_rc=0`）：

```
[OK] 宿主版本一致（app = 0.2.2）
[OK] 已还原工作区「default-workspace」→ <B>\app\workspace\SquadLink（1 个文件，字节保真）
[OK] 工作区登记表已按 ID 合并 → <B>\home\storages\workspace.json（1 个工作区）
[OK] 会话 projcache 的 cwd 已对齐本机路径：修正 1 个
[OK] 会话数据全量还原：写入/更新 1 个文件、备份 1 个
[OK] 全部 0 个插件依赖已就位
```

### 从零验证时最容易踩的五个点

| 现象 | 原因 | 办法 |
|---|---|---|
| `参数里的 -AppRoot 对不上，已自动改用：D:\DeepSeekHarness` | `Resolve-DshAppRoot` 只认目录里有 `resources\app.asar` 或 `resources\app\package.json`；假客户端/绿色版少了这两个就退回注册表里的真实安装 | 显式传 `-AppRoot` 时确保该目录有这两者之一 |
| `[X] 已停止（未抓取、未提交）` | 检测到 `DeepSeek Harness.exe` 在跑，怕抓到写了一半的 `cordis.patch.yml` | 完全退出（含托盘）后重跑，或加 `-Force` |
| `目标 profile 不存在` | 新机器的 `.dsh` 还没被客户端初始化过 | 先装同版本客户端并启动一次 |
| `本机没有可用的内置运行时` | `<AppRoot>` 下没有 node.exe / 客户端本体 | 装完整客户端；或让 `node.exe` 可被找到，否则会话 cwd 不会被改写、会话列表为空 |
| 工作区资料到了，但 `~\.dsh\settings.json` 里的自定义键没同步 | 插件配置是**白名单制**（13 项逐个文件），不整份搬 `settings.json` | 需要同步的配置请确认它属于白名单（见「插件配置跟得走」） |

---



## 包含什么

| 路径 | 说明 |
|---|---|
| `index.js` | 宿主半身：`/config-sync/status`、`settings`、`auto`、`update`、`scope`、`conflict` 路由 |
| `client.js` | 浏览器半身：侧栏行、面板、设置摘要行 |
| `cordis.patch.yml` | bundle 补丁层（`id: config-sync`） |
| `runtime/` | 退出后执行的六个 PowerShell 脚本 + `fix-session-cwd.mjs`，随包发布，点「立即推送/拉取/还原」排队后自动执行 |
| `tools/` | `selftest.mjs`、`clientcheck.mjs`、`pack-plugin.ps1` |
| `version.json` / `releases/` | 自更新清单与安装包 |

## 入口挂在哪

| 入口 | slot | 说明 |
|---|---|---|
| 左侧栏一行 | `sidebar.panellist`（`id: config-sync`） | 与「插件 / 自动任务 / 技能市场 / 记忆系统」同列 |
| 点开的面板 | `main`（`key: config-sync`） | 两条 register 必须在**嵌套 inject** 里成对完成（只 inject `main` 时向 `sidebar.panellist` register 无效） |
| 设置摘要行 | `settings.general.item` | 一行四态 chip + 展开（仓库、远端、私钥） |

## 面板显示什么

从上往下：

- **标题行**：`配置同步　本机 [一致/待推送/待拉取/有问题]　云端 [一致/不一致/待拉取]`。本机徽标看配置齐不齐、依赖缺不缺、有无未提交/未推送；云端**全自动**（打开面板查一次、之后每 2 分钟复查），没有手动按钮。右上角「重新检测」与「本机路径」按钮。
- **元信息行**：`app 版本 / Electron 版本 · 分支 @ 短 HEAD`。
- **指标条**：`本机 / 契约`、`bundle`、`依赖`、`备份快照`、`上次同步`（后面 `(+N)` 表示之后又写入了几个文件）。有事才在下面出现「待办」。
- **分区**：概览 → 本机路径（**默认整块不显示**，点标题行「本机路径」按钮展开，有待处理项时按钮变橙带数量）→ 同步冲突（真有冲突时才出现）→ 同步目标 → 自动化与插件更新 → 退出后执行 → 还原备份 → 同步内容 → 问题反馈。

**统一交互**：所有卡片**先只读，点「修改」才解锁**，改完「保存」生效，「取消」丢弃。没配过的卡强制停在编辑态。

**「待推送」不只看 git**：`git status` 干净时新会话/新资料可能还在 `~\.dsh` 里没 capture。`status` 按 mtime 比对 `sessions`、`skills`、`.agent-presets`、`mnemon`、profile 文件、工作区目录，晚于上次同步的计入待推送。只看 mtime，上限 20000 文件 / 1.5 秒。

**「待拉取」= 本机仓库还是空目录**（不报异常，橙色徽标 + 「执行拉取会从云端拉到这里」）。

**上次自动同步的结果**：`~\.dsh\auto-sync-result.json` 若在 15 分钟内，客户端启动即弹一条 5 秒浮层（成功/失败 + 原因 + 日志路径），同一份结果只弹一次。

## 本机仓库 / 云端仓库

- 仓库判据：目录里同时有 `apply.ps1` 与 `profile\package.json`（再有 `sync.ps1` 才算能推拉）。
- 优先级：本机设置文件 → 插件配置 `repoPath` → `DSH_CONFIG_REPO` → 常见位置探测。**配置里填的空目录同样算有效答案**。
- 四态（`repo.phase`）：`ok` 真仓库、`empty` 空目录/待首次拉取、`missing` 目录不存在、`unusable` 有别的文件却不像仓库；`repo.pushAllowed` / `repo.pullAllowed` 按它算。
- **空目录 + 云端有内容 → 只允许拉取**：推送按钮置灰，宿主 `auto(push-now)` 一律 400。拉取会 `git init` → 补 `origin` → `fetch` → `checkout -B <分支>`（用 init+fetch+checkout 而非 clone）。
- **两边都空 → 只允许推送，且就是「初始化推送」**：`status` 给 `repo.remoteHeads` / `repo.remoteEmpty` / `repo.mode`（`ok|await-pull|await-init`）；执行时按上面的顺序写骨架 + capture + 提交 + `push -u origin main`。
- 云端有没有内容用 `git ls-remote --heads` + 临时 bare `fetch --depth 1 --filter=blob:none` + `ls-tree -r` 数**文件数**（15 秒超时）。**探不到（离线/认证失败）就按老规矩只允许拉取**；`remoteFiles===0` 一律算「两边都空」，用 `--force-with-lease` 覆盖那个空分支（树是空的，不丢数据）。
- 只有隐藏项算"空"；其余文件在却不具备仓库特征 → `unusable`。
- 远端地址优先 `git remote get-url origin`，没有才回落到设置文件；SSH 私钥只存**路径**、可留空交给 `.ssh\config`。
- **没配过 = 强制设置**：卡片停在编辑态、不给「取消」，顶部红字、推送/拉取按钮禁用。
- 保存顺序：校验（地址只接受 `git@host:path` / `ssh://` / `https://`；私钥填了必须存在）→ 写设置 → 有 `origin` 就 `set-url`、没有就 `remote add` → git 失败回滚设置文件。
- 设置落在 `~\.dsh\dsh-config-sync.json`，跟本机走、不进仓库。

## 支持的云端平台

插件不挑托管平台：远端只校验写法，`fetch` / `push` / `pull` / `ls-remote` 全交给 git。Gitee、GitHub、GitLab、自建 Gitea/Forgejo 走同一条路。

| 项 | 说明 |
|---|---|
| 地址写法 | `git@host:owner/repo.git`、`ssh://git@host:port/owner/repo.git`、`https://host/owner/repo.git` |
| 默认分支 | 先试 `main`，没有就取远端第一个分支（老仓库 `master` 也行），拉取后自动建 tracking |
| 认证 | SSH 填私钥路径（留空交给 `.ssh\config`），脚本用 `GIT_SSH_COMMAND` + `StrictHostKeyChecking=accept-new`；HTTPS 用 Git 凭据管理器，插件不存密码 |
| 报错自检 | fetch/pull 失败时提示里的主机名取自 `origin` 真实地址；https 地址给 `ls-remote` 检查，不是 `ssh -T` |
| 单文件上限 | 分三档：源头 >100 MB 抓取时就跳过；≥95 MB 提交前从索引剔除并记一笔；50–95 MB 只警告不拦 |

私有库注意：①优先 SSH 地址；②插件**自身更新清单**默认指向作者公开仓库，改成私有库后只有 Gitee 的 raw 会被自动换成 API + token，GitHub/GitLab 私有库 raw 匿名读会失败（已知限制）。

## 有文件没同步上时：窗口末尾 + 面板常驻提示

只要出现「文件没进仓库」，三处会同时告诉你，不用翻日志：

| 位置 | 形式 |
|---|---|
| 退出后的进度窗口 | 在「同步已完成」横幅**之前**打印 `未同步的文件 N 个`：按类分组，每组最多 5 条（类名、相对路径、体积、原因），超出的给「…还有 N 个，完整清单：<路径>」 |
| 配置同步面板 | 「上次自动同步」卡底部常驻黄框：分类计数 + 最多 30 条明细 + 「文件仍在本机，只是没进仓库；下次同步自动复查」 |
| 机器可读 | `~\.dsh\sync-notices.json`（`at/mode/total/byKind/items`，四个 `byKind` 键固定）与 `auto-sync-result.json` 的 `notices` 字段 |

四类 `kind`：

| kind | 什么时候记 | 文件本身 |
|---|---|---|
| `too-large` | 超过单文件上限：抓取时跳过（>100 MB）、提交前从索引剔除（≥95 MB）、拉取时仓库里那个文件不还原 | 留在磁盘，只是不进仓库 |
| `history` | 推送前历史预检发现本地历史提交里已有超限文件 | 远端会拒收整次推送 |
| `skipped` | 按规则跳过（模型权重、`*.whl` 等）或被占用 | 留在磁盘 |
| `failed` | 单文件写入失败、会话头/projcache 修正失败、被远端拒收 | 看 `reason` |

### 推送前两道预检

1. **索引预检**：`git add -A` 之后逐个 stat 暂存文件，≥95 MB 的 `git reset -- <path>` 撤出索引、写进 `.git\info\exclude`（下次 add 不再收），其余照常提交推送——一个大文件不会拖住整次同步。50–95 MB 只警告。
2. **历史预检**：`git ls-tree -r -l HEAD` 扫已有历史，命中 ≥95 MB 就提前报「远端会拒收整次推送（不是网络问题）」，并给两条路：①面板「初始化推送」到一份新的空仓库（配置同步不需要旧历史，最省事）；②`git filter-repo` 清史后强推。**只报告，不自动改写历史。**

### push 失败归因

`git push` 的原始输出不再被一句「网络/认证失败」盖掉，按特征分类：

| 特征 | 结论 |
|---|---|
| `File <path> is X MB; this exceeds ... limit` | 文件超限（逐个列出文件名与体积） |
| `exceeds ... quota` / `repository size` / `仓库容量` | 仓库总量超限 |
| `[remote rejected]` / `pre-receive hook declined` | 远端拒收（无文件名时按通用拒收处理） |
| `Could not read from remote` / `Permission denied` / `publickey` / `Host key verification` / `Could not resolve host` / `timed out` | 网络或认证 |

### 中文路径的坑（0.3.48）

`git` 默认 `core.quotepath=true`，非 ASCII 路径会被转义成 `"workspace/DSH\347\240\264\347\224\262/..."`（**带双引号**）。0.3.47 的索引预检直接读 `& $git ... diff --cached --name-only` 的输出，于是 `Test-Path -LiteralPath` 撞上 `"` 报 `执行体调用异常：路径中具有非法字符`，整次同步在提交前就挂了。

修法：凡是要「按路径干活」的 git 查询一律走 `Read-GitLines`（内部 `-c core.quotepath=false` + cmd 字节重定向 + 按 UTF-8 读），并给逐个 stat 包一层 `try/catch` —— 单个坏名字只跳过体积检查，不再拖垮整次同步。实测真实仓库 918 条暂存路径：含引号 0 条、stat 失败 0 条；历史预检的 `ls-tree -r -l` 3222 条全部能按 `\t` 切出路径与体积。

实测（2026-11-14，隔离仓库 + 本地裸库 + 假 `pre-receive` hook）：96 MB 文件被剔除后其余照推成功、`sync-notices.json` 落盘 `too-large=1`；同一文件进历史后预检报 `history=1`；hook 回放 GitHub 报文（`File big.bin is 96.00 MB; this exceeds ...`）被正确归成「文件超限 1 个」而不是网络问题；窗口末尾汇总与面板区块读的是同一份清单。

## 工作区与会话跟着机器走

跨机可用取决于三处路径是否被换成本机值：

| 位置 | 存的是 | 换机器后怎么办 |
|---|---|---|
| `workspace\workspace-registry.json` | 每个工作区的落点，已写成 `{{APP_ROOT}}/xxx` | 拉取时展开成本机路径，工作区直接开在本机对应目录 |
| `conversations\sessions\--ws-<id>--\...\session.v4.jsonl.zstd` | 会话日志第一帧的 `cwd` | 按「本机这个工作区在哪」重写第一帧，后面的帧一字节不动（靠 Node 解 zstd，找不到执行器时**宁可不铺**） |
| `conversations\session_projcache\<sessionId>.json` | `record.identity.cwd` | 按登记表的 `sessionIds` 反查该工作区在本机的位置再改写；漏了这一步的症状是「工作区能列出来、点开历史会话指着对方机器的目录」 |

推断规则：先看登记表里该工作区的**标题/槽位/相对结构**，在本机展开成绝对路径；会话靠 `sessionIds` 认领同一个工作区，跟着那个落点走，**不靠猜盘符**。推断不出来（路径是绝对老盘符、登记表里没有对应项）就**不改**，留着让面板提示。

推送侧报告分两组：`scope: config` 是配置文件里的路径，`scope: data` 是 `workspace\` 与 `conversations\` 里还指着对方机器的记录，面板分两列展示、都能逐条采纳。

**边界**：默认工作区（`default-workspace`）**不同步**（目录名按各机 `WorkspaceHome` 编码，目标机认不出，只会留下"历史为空"的空工作区）；`models/`、`*.whl`、`*.safetensors` 与任何 >100 MB 的文件也不进仓库。

### 隐藏/归档的工作区不再带到另一台机显示（0.3.75）

在配置同步面板里「隐藏/归档」的工作区与会话，之前推送到 B 机后仍会原样显示。原因：DSH 把隐藏状态单独存在 `<DshHome>\dsh-session-manager\workspace-archives.v1.json`（记录 `archived:true` 与对应 `sessionIds`），这个文件不在同步清单里；工作区登记表又是按 ID 并集合并，本机被隐藏的记录会被并回来。

0.3.75 起把这份状态纳入 `settings` 同步：推送时写进仓库 `settings\workspace-archives.json`，拉取时还原到 B 机同名文件。B 机 DSH 启动后读到 `archived:true` 的工作区，会在工作区列表里过滤掉，它名下的会话也一并归到「已归档」，不再显示。整份覆盖语义——A 机的隐藏状态为准；这是「隐藏」不是删除，工作区与会话文件仍在，随时可以在 DSH 里取消隐藏恢复。

### 配置同步面板新增「工作区显示」卡片（0.3.76）

面板新增一个**工作区显示**分区，把 DSH 原生两套隐藏机制放进同一张卡里直接操作：

| 操作 | 作用 | 落点 |
|---|---|---|
| 显示 | 工作区正常可见，会话全显示 | 清掉归档记录；会话移出 `archivedSessionIds` |
| 隐藏会话 | 工作区留在列表，名下会话进「已归档」 | 会话写进 `<DshHome>\storages\workspace.json` 的 `global.archivedSessionIds` |
| 归档工作区 | 整个工作区从列表消失，会话保留 | `<DshHome>\dsh-session-manager\workspace-archives.v1.json` 写 `archived:true` + 会话一并按隐藏处理 |

每个工作区可独立切三态；展开后还能对单个会话单独「隐藏 / 显示」，两者互不影响（会话操作只动那一条 `archivedSessionIds`，不改工作区归档记录）。改动不调 session-manager 的 Web API（那套 API 需要 DSH connection owner 凭证，插件路由拿不到），而是经宿主 `workspaceRegistry` 落盘并推送会话列表更新，切换后立刻生效（详见 0.3.82）。0.3.75 已把归档文件纳入同步，所以这里改的隐藏 / 归档状态也会跟着 push/pull 到另一台机。

### 配置同步面板：会话名称、修改按钮、点行展开与快速跳转（0.3.77）

在 0.3.76「工作区显示」卡片之上做了五点交互调整：

1. **会话名称**：工作区展开后每条会话显示可读标题（从 `session/title` 事件提取，取不到时回退到首条用户消息文本），鼠标悬停可看完整会话 ID；标题提取带缓存，换机器后按新机器日志重建。
2. **修改按钮**：三态下拉与会话的「隐藏 / 显示」按钮默认不出现，点该工作区的「修改」才进入编辑态，点「完成」退出，避免误改。（0.3.84 起改为**整卡一个**「修改」按钮，见下文。）
3. **点行展开**：点工作区整行即可展开 / 收起会话，不再单独点展开按钮。
4. **卡片位置**：工作区显示卡片移到「问题反馈」前，作为配置调整的最后一步。
5. **固定标题 + 快速跳转**：面板标题栏吸顶；标题下方增加快捷标签（概览 / 工作区显示 / 同步目标 / 自动化 / 生成脚本 / 还原备份 / 同步内容 / 插件数据 / 问题反馈），点击平滑滚动到对应分区。

会话标题读取与三态读写都在本插件内自包含完成，不依赖 session-manager 的 Web API。

### 快速跳转顺序与卡片对齐、滚动不再被标题遮挡（0.3.78）

0.3.77 的两处显示问题已修：

1. **跳转顺序对齐卡片**：快捷标签顺序改为与分区实际渲染顺序完全一致（概览 / 同步冲突[有冲突时] / 本机路径[展开时] / 同步目标 / 自动化与插件更新 / 生成脚本 / 还原备份 / 同步内容 / 插件数据 / 工作区显示 / 问题反馈）。同步冲突、本机路径两个条件分区只在卡片存在时才出现在标签里。
2. **滚动落点在标题下方**：标题栏改为不透明背景（面板卡片同色），滚动时内容不再从标题背后透出；点标签跳转时按标题栏实际高度设置滚动落点，目标分区完整显示在标题下方，不再被遮住。

### 插件更新支持 npm 双源兜底下载（0.3.89）

「插件更新」卡新增一行 **npm 下载路径**，直接显示实际兜底地址（国内镜像 `registry.npmmirror.com` + 官方 `registry.npmjs.org` 两个源）。GitHub release 整段不通时（国内常见），更新包会自动兜底从 npm 下载；仍按 `version.json` 里的权威 sha256 校验，换源不放宽校验。两个源互为备份：镜像首发同步窗口期会短暂 404，官方源随即兜上。实测 npm tarball 与 GitHub release tgz 是同一份产物、sha256 完全一致。

### 面板视觉重构：杂志编辑风格（0.4.26）

本版只动**显示层**，接口、请求体、状态判据、文案词条、分区顺序与 0.4.25 完全一致，行为零改动。

- **不引任何前端依赖**：样式通过一段 `<style id="dsh-config-sync-theme">` 注入，`injectTheme()` 幂等（已存在就直接返回），`apply()` 首行调用。没有 Tailwind / shadcn / Google Fonts，包体不增大。
- **刊头与章节眉标**：页头加一行眉标「DSH 插件 · 配置同步 ——— v0.4.26」；每个分区标题上方加序号眉标（`01 · 状态`、`02 · 冲突` … `10 · 反馈`）+ 右侧细线 + 一句话说明。
- **跳转条改下划线 tab**：原来是胶囊按钮，现在是无边框 tab，当前区用品牌色 2px 下划线 + 加粗标出，等宽大写小字号。
- **卡片与动效**：卡片悬停上浮 2px + 顶部渐变细线；分区入场 staggered fade-up（55ms 递增延迟）；warn / error 徽标缓慢呼吸。`prefers-reduced-motion: reduce` 下动效全部关闭。
- **配色全部走宿主 token**：只用 `--dsw-alias-*` 与两个新定义的品牌色 HSL 变量，深浅色主题自动跟随，不写死色值；字体栈避开 Inter / Roboto / Arial。

实测：`node --check` 双文件通过、`tools/selftest.mjs` **416 项全 OK / 0 失败 / 0 跳过**、`tools/clientcheck.mjs` 全通过、真实 React 运行时深度渲染（4 套数据形态、28 个按钮、5 个输入）0 失败，面板浅色/深色两版目视正常。

### 0.4.23（2026-11-28）

- **跨机隐藏对齐**：修复「另一台机器拉取后工作台多出 MnemonSkills 会话 / 未命名会话」。Mnemon 后台会话（id 前缀 `mnemon-*`）与子代理会话（纯 uuid id）本来就会被登记进各机 workspace.json 并随同步带到对端；DSH 对 `origin=subagent` 与空会话有视图级折叠，但同步来的会话不在折叠边界时（如 mnemon-task 带 turn/start、同步日志里的首条用户消息让空会话判定失效），对端就会把它们列出来。拉取时现在把这两类会话 id 并进 `global.archivedSessionIds`（DSH 原生隐藏通道，列表/搜索/打开全链路拦截）：**会话体照常同步保留，只是工作台不再显示**；主会话（`session-` 前缀）不受影响，本机手动隐藏/归档的会话照常保留。升级后重新点「立即拉取」即自动对齐。

### 0.4.22（2026-11-28）

- **默认工作区跨机收敛**：修复「另一台机器拉取后登记表里出现两个 default-workspace（幽灵条目指向本机不存在的 C:\Users\... 路径，其 2 个会话没有落点目录）」。老仓库快照里 default-workspace 条目带着已废弃的 `{{ROOT:userHome}}` 展开产物，而本机 Documents 重定向后默认工作区实际在别处（如 `D:\Backup\Documents\...`），两条 path 不同 → 原有的同路径收敛认不出来。apply 现按 slot/title=default-workspace 语义把仓库条目的三组会话 id 并入本机默认工作区条目后丢弃仓库条目；本机没有默认工作区条目时保留仓库条目（首次迁移不受影响）。升级后重新点「立即拉取」即自动收敛，幽灵条目消失、默认工作区会话数变为「本机 + 仓库」之和。

### 0.4.21（2026-11-27）

- 修复插件更新安装失败：0.4.20 起改用 pnpm publish 发包，npm 兜底源下到的包顶层是「包名/」目录，旧安装器只认 npm 标准的「package/」，报「安装包结构不对」。更新器现兼容两种结构（post-exit / install-plugin / apply 三处解包点）。

### 拉取崩溃修复：int+字符串拼接改 -f 格式化（0.4.20）

本版修复 0.4.19 在另一台机器上拉取崩溃、随后自动回滚导致「拉取成功但工作区/会话是空的」的问题：

- **根因**：Test-PullLanding 的报告文案里有一处 int 与字符串直接拼接（`$bad + " 个会话投影缓存仍含占位符…"`）。PowerShell 对 `int + string` 会先把左侧 int 当作左操作数语义、试图把右侧字符串转成 Int32，StrictMode 下直接抛终止错误「无法将值"个会话投影缓存…"转换为类型 System.Int32」。Test-PullLanding 挂掉 → sync pull 退出码 1 → post-exit 按「执行体没有正常跑完」处理，触发自动回滚（仓库 reset --hard + 配置快照还原），刚落地的工作区/会话数据被整段撤销。本机不崩是因为该分支只有 landing 提示路径差一层才走到，另一台机器（本机 sessions 为空 + projcache 有占位符）恰好命中。
- **修复**：所有 int 邻接拼接统一改 `-f` 格式化，共 14 处——apply 的 projcache 计数（崩溃点）/重复路径/会话目录计数/待确认路径/覆盖清单/Skill 多出/记忆文件清理，capture 的绝对路径告警三连，post-exit 的备份名与校验日志，restore 的落地清单 key/manifest 拼接。其余 string+string 拼接逐一核对过类型，安全保留。
- **升级指引**：从 0.4.19 升级后重新点「立即拉取」即可；此前被回滚掉的数据会随本次 pull 重新落地（仓库里还有，回滚只动了本地）。

### 契约单向采纳 + 落地链路加固（0.4.19）

本版集中修复通读审计发现的五类问题：

- **契约防降级不再冻死**：旧逻辑「本机版本 ≠ 仓库契约就保持不变」让 app 每次 nightly 升级后契约永久冻结在旧版（`host-contract.json` 一直停在 rc.2，实验 bundle 门控对着旧版本判断）。现在按 semver 单向采纳：本机比契约新→升级契约；本机更旧→维持不变（保留防降级意图）。
- **初始化契约读错版本**：打包版（app.asar）机器做初始化推送时，旧回退链读到的是 Electron 框架版本（44.7.0 之类）写进契约。现在复用 `Get-HostAppVersion` 的正确读取链（asar 手工解析），任何构建形态写入的都是真实 app 版本。
- **硬编码版本四处脱节**：apply 里 lock 兜底版本、`$cssFallback`、landing 探测名单、23 个 link 目录名映射全部改为从仓库 `package.json` 运行时推导，发新版不再需要手工同步四处，`--frozen-lockfile` 不再因版本错位必挂。
- **推送前先核对云端**：capture 的镜像删除以「本机没有 = 删仓库」为准，另一台机器刚推过而本机没拉时会静默删掉对方独有的文件（会话/附件不可再生）。现在 push 前先 fetch 并检查 behind>0，领先就停（-Force 可越过）。
- **WorkspaceOnly 竞态收口**：`-WorkspaceOnly` 分支原来绕过 DSH 运行检查，会和运行中的客户端互踩 workspace.json/会话日志/bili 数据库。进程检查现在提到该分支之前。

附带：`git add -A` 改走 cmd 转发（EAP=Stop 下不再被 stderr advice 中断）；push 失败分类补 non-fast-forward（双机竞态给出「先拉取」指引）；capture 会话头归一执行器统一走 `Get-HostNodeRunner`（无独立 node 时不再 `& $null` 崩溃）并用 `$PID` 命名临时文件；notices byKind 补 `landing` 计数；面板 AutoCard 的 auto 请求统一走 callAuto；同步内容卡必需组单项勾选禁用（原本就是死开关）。

### 跨机配置完全同步：Windows-MCP 版本状态 + MCP 连接器 + 桥行路径（0.4.24）

本版补齐三类此前不同步或不正确的配置：

- **Windows-MCP 版本状态**：`~\.dsh\dsh-windows-mcp.versions.json`（active/previous/history/lastCheck）是 `.dsh` 根散落文件，此前 `plugin-data` 只扫一级目录、`settings` 白名单也没它，跨机一直丢。本版纳入 settings 组同步。
- **MCP 连接器配置**：此前 `mcp-connectors` 是空壳组——面板有声明、capture 只建空目录、apply 完全没有代码。本版补上 `~\.dsh\storages\mcp_connector.json` 的真实抓取与还原（含 OAuth/API Key 凭据，覆盖前自动备份）。
- **桥行 exe 路径**：`cordis.patch.yml` 里 windows-mcp-bridge 的 command 是 `C:\Users\xxx\.dsh\...` 绝对路径，此前只 token 化 AppRoot、漏了 DSH_HOME，换机后桥接指向旧机路径失效。本版把 DSH_HOME 也 token 化，跨机自动展开为本机路径。

### 修复拉取前置检查过严（0.4.18）

本版修复 0.4.17 新增的拉取前置检查在目标机误报失败、导致拉取被回滚的问题：

- **link 归档误报**：前置检查只找 `.tgz` 归档，但仓库里 `dsh-our-free-model-2.8.0` / `dsh-purge-1.4.0` 实际是 `.zip`。明明归档存在却报「缺失」，直接拦死拉取。本版改为同时认 `.tgz` 与 `.zip`，与 apply 的解压逻辑一致。
- **workspaceHome 误判**：全新机器首次拉取时工作区资料根还不存在是正常的（apply 落地时会自动建）。本版改为目录不存在就自动补建、路径未确认就用默认 `~/Documents/deepseek-harness`，不再因此拦死拉取。
- **效果**：目标机首次拉取不再因前置检查失败而回滚，工作区与会话能正常落地。

### 拉取落地加固：另一台机器拉取即可用（0.4.17）

本版修复「另一台机器拉取同步后，左侧工作区与会话同时为空」的问题：

- **根因**：工作区/会话组可被误取消勾选；本机根路径未确认、`link:` 插件本地目录缺失、bundle 未解析都可能让 apply 中途退出或让 DSH 读到空表；bundle 未解析时脚本非零退出还会触发 post-exit 回滚，把已经落地的工作区/会话一起擦掉。
- **前置检查**：拉取在进入 apply 前检查工作区/会话同步组、`-SkipWorkspace`、本机 appRoot/workspaceHome 与 `link:` 插件目标，缺项直接给出明确诊断（写入 sync-notices.json），不再「拉完是空的」。
- **不回滚**：bundle 未解析从「Die 停止」改为记 notice 并继续落地，避免把已同步的工作区/会话回滚掉；需要严格检查仍可用 `-ForceBundles`。
- **落地验证**：apply 结束后核对 `workspaceIds` 非空、默认工作区 ID 不悬空、无重复路径、会话目录已铺回、projcache 无占位符残留、`link:` 插件齐备，结果写 `pull-landing-check.json` 并在面板可查。
- **必需组**：工作区资料、会话记录与 profile 一起列为必需同步组，面板不可误取消，从源头堵住「勾选漏了导致空列表」。
### 修复跨机器拉取后 bundle 解析失败（0.4.16）

本版修复目标机器拉取配置后 DSH 启动报 `cannot resolve profile bundle "dsh-config-sync-plugin"` 的问题：

- **根因**：本机开发时 `dsh-config-sync-plugin` 是 `link:` 本地源码依赖，capture 把 `link:{{APP_ROOT}}/dsh-config-sync-plugin-xxx` 写进仓库；目标机 AppRoot 下没有该源码目录、`local-plugins` 也无对应归档，pnpm install 装不上，启动期 bundle 解析失败。
- **修复**：capture 把该 link 依赖归一为 npm 版本（读本机已装插件真实版本），apply 兜底改写老仓库残留的 `link:`（package.json 与 pnpm-lock.yaml 同步），目标机 pnpm install 直接从 registry 安装，DSH 正常启动。

### MCP 连接器同步修复（0.4.15）

本版修复 MCP 连接器同步功能在 PowerShell 运行时脚本中缺失导致的同步失败问题：

- **根因**：v0.4.14 新增了 MCP 连接器同步组，但 PowerShell 运行时脚本（`dsh-sync-common.ps1`、`capture.ps1`）的硬编码组列表未同步添加 `mcp-connectors`，导致捕获/应用时跳过该组，配置无法同步。
- **修复**：在 `dsh-sync-common.ps1` 的 `$SyncScopeGroups` 和 `capture.ps1` 的硬编码组列表中添加 `mcp-connectors`，与 `index.js` 的 `collectScopeGroups` 保持一致。

### 新增 MCP 连接器同步支持（0.4.14）

本版把「待推送」从时间戳判据改为内容级判据，只修误报、不改变正常推送/拉取流程：

- **消除 mtime 假变更**：DSH 重写 `cordis.patch.yml`、会话 `projcache` / `session-index` 时只改时间戳不改内容，不再被判为待推送。
- **内容指纹基线 + `pendingKeys`**：以内容指纹为基线识别真正变化，`pendingKeys` 防止双方同内容互相洗白。
- **db/sqlite 不漏检**：≤64MB 的 db/sqlite 走全量 hash，避免同尺寸原地更新只看大小/mtime 时漏检。
- **判据同步**：`autoPush` 与退出推送使用同一套新口径，不再一边按内容、一边按时间戳。
- **验证**：隔离审查两轮无阻断项，`selftest` 无新增失败。

### 代码整理与一致性修复：等价重构，功能不变（0.4.11）

本版是一次等价重构，正常同步路径与 0.4.10 完全一致，不改变任何用户可见功能：

- **门禁判据收敛**：`pushAllowed` / `pullAllowed` 抽成 `canPush()` / `canPull()` 统一函数，判据与原来逐字等价；退出关闭路径的 fast 判据保持原样，不引入新的放行条件。
- **少一次远端请求**：定时复查已经 `git fetch` 得到 drift，直接复用并传给 `checkAndQueueAutoSync`（`driftOverride`），不再重复 fetch。
- **强杀幂等**：1.5 秒内多次触发强杀只执行一次，避免窗口关闭钩子 / 定时预排 / 前端信标三路重复杀同一进程族。
- **单一定义**：插件根目录与版本收敛到 `PLUGIN_DIR` / `PLUGIN_VERSION` 单一来源；删除从未调用的 `lsRemoteHeads`、死导入与未使用的 state 等死代码。
- **一致性修复**：`market-index.json` 的 `publishTimestamp` 统一为毫秒；前导零版本补 `npmVersion` 字段；打包排除 `_stage-*` / `_refactor-*` / `*.bak*` 等临时产物；还原流程的 AppRoot 探测与实验 bundle（`app.asar`）识别对齐主链路；语言头改为请求时计算（切换语言后 POST 也跟随）；`callUpdate` 补失败判断。

自测：`node --check` 四项、`selftest.mjs`、`clientcheck.mjs` 全部通过。

### 点 × 立即执行待推送/待拉取：后端窗口监视（0.4.06）

0.4.05 把「点 × 后没执行」的根因定位到前端信标送不到后端，用 2 分钟定时复查预排 watcher 绕开。但预排有窗口期：用户在两次复查之间点 ×，那一刻既没有预排 watcher、信标又送不到，退出后就什么都不执行。

0.4.06 把这个判断彻底搬到后端，不再依赖任何浏览器事件：插件 apply 时起一个常驻 PowerShell 采样进程，每 250ms 报一次「DeepSeek Harness 的可见窗口数 / 进程总数」。判据是「曾经有过可见窗口，现在连续 4 拍（约 1 秒）一个都没有」——最小化仍有窗口句柄，不算关闭；页面重载不销毁 BrowserWindow，也不会误判。命中后当场调 `triggerAutoSyncOnClose(fast)` 判一次 drift：确有待拉取/待推送才排队 watcher 并强杀残留进程族让它立刻开工，没有待同步内容时绝不强杀，让客户端走正常退出流程（不跳过落盘）。前端信标与 2 分钟预排都保留作双保险。

配套收紧了 watcher 的两条判据：`post-exit.ps1` 的 wait 段改成「可见窗口归零 3 拍即收拾残留进程开工」，不再等 60 秒批次年龄（那正是「点 × 后要等一两分钟才动」的原因）；过期 watcher 让位从「WatchPid 消失且无遗留前台窗口」收紧为「等待已超 5 分钟且从未见过窗口」，避免把点 × 后刚排好、正要开工的 watcher 自己让掉。

前提不变：必须勾选「启动时自动拉取」/「退出时自动推送」，否则退出时不做任何同步（0.4.01 起的行为）。

### 点 × 有待推送却没推送：改后端定时预排 watcher（0.4.05）

端到端诊断（手动 POST `/config-sync/auto-exit`）证明后端判据与路由完全正常——立即返回 `queued:true`、排上 watcher、强制退出 DSH 并完成推送。根因在前端：`pagehide → navigator.sendBeacon('/config-sync/auto-exit')` 在 DSH 真正退出时请求送不到后端（launch.log 里点 × 时段无任何信标到达记录），而 0.3.96 起一直依赖它，代码级自测过、真实 UI 却从未验证到。

改为不依赖前端信标的可靠架构：后端 2 分钟定时复查检测到待拉取/推送时，直接排队一个 watcher 进 `wait` 态（`shouldCloseDsh:false`，**不关闭 DSH**）；用户点 × 关闭 DSH 后，预排的 watcher 自动进入 run 执行推送/拉取。前端信标保留作双保险——它若送达，发现已排队会直接复用，不会重复。配套：定时复查无人值守不弹确认框、已排队守卫检查 watcher 存活（超时后允许重排）、开关每次复查重新读取。selftest 加 4 条断言防回归。

### 修复点 × 关闭后 watcher 被孤儿进程卡在 wait（0.4.04）

点 × 关闭后 push watcher 已经排上，但可能卡在 wait 阶段迟迟不执行。根因：`WatchPid` 被强杀后，常留下一个**无前台窗口的孤儿 DSH 子进程**（启动时间比 watcher 还早，父进程已死）。僵死 watcher 自清的旧判据要求「所有现存 DSH 都比 watcher 新」，这个孤儿进程把它永久破坏——`newerAll.Count ≠ byName.Count`，watcher 死等 30 分钟还霸占 `auto-sync.lock`，新 watcher 也没法接管。判定改成「有没有比 watcher 更早、且有前台窗口的 DSH 实例」：真正代表「排队那次 DSH 还在用」的是有窗口的实例；无窗口残留和新实例都不该挡住让位，watcher 立即 `exit 3` 清锁让新 watcher 接管。selftest 加断言防回归。

### npm 兜底下载的版本规范化修复（0.4.02）

npm 按 semver 把版本号 `0.4.01` 规范化成 `0.4.1`，tarball 文件名是 `dsh-config-sync-plugin-0.4.1.tgz`。0.4.01 之前拼的是 `-0.4.01.tgz`，npm 兜底下载会 404。`npmTgzUrls` 现在对数字段去前导零（`0.4.01`→`0.4.1`）再拼 URL；GitHub release 与 version.json 仍保留用户指定的版本号（同一份产物、sha256 一致）。selftest 加断言防回归。

### 项目级技能纳入同步 + 自动同步仅在主动关闭 DSH 窗口（×）时触发（0.4.01）

**项目级技能同步**：技能放在工作区的 `.dsh\skills\` 下时，之前从来不会被同步——工作区同步的忽略清单把整个 `.dsh` 目录跳过了。现在 `Test-WorkspaceIgnored` 给 `.dsh\skills\` 开定向例外，项目级技能能随工作区资料一起推送/拉取；其余 `.dsh` 内容（会话缓存/token/配置）仍照旧跳过。

**自动同步时机**：以前勾选「启动时自动拉取」或「退出时自动推送」后，立即判 drift → 满足条件即排队 watcher 并关闭 DSH（0.3.99）。这会导致用户只是在面板改开关、或 2 分钟周期到达时，DSH 就自动关闭重启，体验很差。

现在把核心判断 `checkAndQueueAutoSync` 拆出 `shouldCloseDsh` 参数，三路明确分工：

1. **scheduleAutoStart**（启动 8 秒后 + 每 2 分钟复查）：**只做 drift 检查与状态更新，不自动关闭 DSH**，供面板显示「云端领先/本地未提交」等状态
2. **handleSettings**（开关保存后）：**只排队 watcher（shouldCloseDsh: false），不自动退出**，开关变更即时生效但不干扰正在用的 DSH
3. **triggerAutoSyncOnClose / handleAutoExit**（点 × 关闭 / 页面卸载）：**shouldCloseDsh: true**，排队后真正关闭 DSH，watcher 在 DSH 退出后立即执行

现在的行为：勾选开关 → 即时判 drift 并排队（面板状态立即刷新），但 DSH **不会** 自动关闭；只有用户**主动点 × 关闭窗口**时，才会按已排队的模式真正执行拉取/推送。selftest 加断言防回归。保留 0.3.93-0.3.99 全部修复。

### 勾选自动同步开关即时触发判断（0.3.99）

以前勾选「启动时自动拉取」或「退出时自动推送」后，必须等到下一个 2 分钟周期（或退出 DSH）才会判断是否需要同步。这次把核心判断逻辑抽离为 `checkAndQueueAutoSync`，在三处复用：

1. **scheduleAutoStart**（启动 8 秒后 + 每 2 分钟复查）
2. **triggerAutoSyncOnClose**（点 × 关闭时）
3. **handleSettings**（开关保存后）

开关保存后，若已开启且仓库就位，立即判 drift→满足条件即排队 watcher 并关闭 DSH；手动触发模式（开关变更）跳过确认框，直接排队。不再有「勾了开关、等 2 分钟才动」的延迟。selftest 加 5 条断言防回归。保留 0.3.93-0.3.98 全部修复。

### 默认工作区会话纳入同步、资料仍各机独立（0.3.98）

以前默认工作区整个跳过同步。原因：它的会话目录名由**本机 WorkspaceHome 绝对路径**编码（`--C-Users-...-default-workspace--`），两台机器路径不同，直接把 A 机的目录铺到 B 机只会留下 DSH 认不出的死目录（表现为默认工作区历史为空）。这次按「只同步会话、不同步资料」拆开处理：

1. **会话走跨机稳定名**：capture 把默认工作区会话目录写成稳定名 `--default-workspace--`（和已有工作区的 `--ws-<id>--`、`--im--` 并列），会话头 cwd 归一到 `{{WORKSPACE_HOME}}/default-workspace`；apply 按**本机** `workspace.json` 的 `global.defaultWorkspaceId` 反查本机默认工作区路径，重编码目录名、改会话头 cwd、对齐 projcache，并把会话 id 并入本机默认工作区登记条目——DSH 才能把这些会话显示在默认工作区下。不依赖 A 机的工作区 ID。
2. **资料不同步、登记保留**：capture 按 `defaultWorkspaceId` 跳过默认工作区的资料文件拷贝（资料各机独立），但 `workspace-registry.json` 里它的登记条目保留——会话归属与 sessionIds 合并不需要它。apply 侧资料还原也不会把默认工作区资料槽铺回来。
3. **防回归**：selftest 加 10 条断言（稳定名映射、cwd 归一、本机路径反查、重编码、sessionIds 合并、资料跳过）。普通工作区、im、其余机制与同步内容勾选过滤全部不变。首次拉取前 B 机需先让 DSH 启动一次生成默认工作区登记。

### 点 × 检测到待同步就主动退出 DSH 并立即执行（0.3.97）

0.3.96 的信标已经能「点 × 判一次并排好 watcher」，但 watcher 进入 `wait` 后是**被动等 DSH 进程全部消失**才开工。实测点 × 后 DSH 常残留 7 个进程（插件就跑在其中的 host 子进程里），单靠正常关闭流程经常关不干净，watcher 只能干等到 30 分钟超时——表现为「排了队但迟迟不动」。这次补上最后一环：

1. **主动强制退出**：`handleAutoExit` 一旦 `triggerAutoSyncOnClose` 返回 `queued:true`（确实有待拉取/待推送），立即调 `forceCloseDshDetached`——从**独立 detached 进程**用 `taskkill /IM "DeepSeek Harness.exe" /F` 整族强杀（中间用 `ping -n 3` 留 2 秒给正常关闭落盘）。必须在独立进程里做：强杀会把插件自己（host 子进程）也带走，任何挂在插件进程内的 `setTimeout` 都来不及执行。
2. **只在真有待同步时才退出**：`if (result && result.queued)` 守卫——没待同步就点 × 不会误杀 DSH；有待同步才「退出 + 拉取/推送」一气呵成。
3. **防回归**：selftest 断言 detached 强杀、`/IM /F`、排队后调用与 queued 守卫。

### 页面卸载信标取代 Electron 关窗钩子，真正修好「点 × 不触发」（0.3.96）

0.3.95 修好 BOM（watcher 不再启动即崩）后，「点 × 还是不触发」的真凶才浮出水面：**Electron 关窗钩子根本没装成功**。两条铁证——插件实际跑在 host 子进程（`dsh-desktop-host`，`--expose-internals` 的 node 进程），`require('electron')` 拿不到 `app`，`electronApp()` 返回 null，`installQuitWhenAllWindowsClosed` 一进来 `if (!el) return` 直接退出；并且就算拿得到，`browser-window-created` 在插件 `apply` 时窗口早已建好，那个事件再也不会触发，`closed` 回调永不执行。所以从 0.3.93 加的「点 × 判一次」这条链**从未真正跑过**（launch.log 无新 watcher、钩子日志 0 命中）。这次彻底换路：

1. **前端卸载信标**：`client.js` 在 `apply()` 里装 `pagehide` + `beforeunload` 监听，页面卸载（点 × / 关标签 / 进程退出）时用 `navigator.sendBeacon('/config-sync/auto-exit')` 发一个 fire-and-forget 请求——完全不依赖 Electron 事件。全程 `typeof` 守卫，没有 `navigator.sendBeacon` 的环境静默跳过。
2. **后端 fast 判据**：新增 `/config-sync/auto-exit` 路由，`handleAutoExit` 调 `triggerAutoSyncOnClose(config, { fast: true })`。fast 模式只读本地 tracking ref（`rev-list HEAD...origin/branch`，毫秒级）算 ahead/behind，**绝不 `git fetch`**——`sendBeacon` 到达后插件进程随时会被 DSH 退出杀掉，来不及等秒级的网络 fetch；拉取/推送判据与启动复查一致，拉取优先。排好 watcher 后立即返回，真正的 pull/push 由独立存活的 `post-exit.ps1` 在 DSH 进程全消失后执行。
3. **防回归**：selftest 断言新路由/handler/fast 分支/无 fetch/clientcheck 断言 `sendBeacon` 与 typeof 守卫。0.3.93/0.3.94/0.3.95 的修复全部保留。

### 修复 post-exit.ps1 丢 UTF-8 BOM 致排队同步全崩（0.3.95）

前面几版「勾了自动拉取/推送、点 × 还是不触发」的最终根因，既不在排队逻辑也不在关闭钩子，而在**执行体脚本的编码**：0.3.94 编辑 `post-exit.ps1` 时，写入工具把文件开头的 **UTF-8 BOM（`EF BB BF`）弄丢了**。Windows PowerShell 5.1 遇到无 BOM 的中文 UTF-8 脚本会按 GBK 解码，中文全角括号被解成引号，脚本一启动就报 55 处语法错直接退出。结果：watcher 明明排上了（`auto-sync-launch.log` 有「已启动」），但 `auto-sync-wait.log` 没有新的「等待开始」——所有排队的同步（启动首检、2 分钟复查、点 × 触发）全部启动即崩，表现成「完全没触发」。

1. **执行体补回 BOM**：`post-exit.ps1`（插件 runtime、配置仓库镜像、实际部署目录三处）用 `UTF8Encoding($true)` 重写补回 BOM，`ParseFile` 语法错误从 55 降到 0，隔离探针实测 wait 段能正常启动、写日志、持续存活。
2. **防回归断言**：`selftest.mjs` 新增检查——所有 `runtime/*.ps1` 必须带 UTF-8 BOM（前 3 字节 `EF BB BF`），`post-exit.ps1` 执行体单独再验一次。以后再有人编辑脚本丢了 BOM，自测直接红。
3. **打包保持 BOM**：`fs.copyFileSync` 原样复制不会丢 BOM；本次是源文件被编辑工具写坏的，打包产物核验包内 `post-exit.ps1` 带 BOM。

### 清理跨重启僵死 watcher，锁不再被旧实例占死（0.3.94）

实测「勾了开关、点 × 关闭还是不触发」还有一个更深的原因：插件更新流程重启 DSH 后，更新前排的那个 watcher 还在等**已经退出的旧 DSH 进程**（WatchPid 已死），却被 post-exit 的「进程名还有新实例」判断挡着不敢开工，于是僵死在 wait 段、一直占着 `~/.dsh/auto-sync.lock`。此时点 × 新排的 watcher 看到锁里 pid 存活且同为 push，就误判「同一个同步正在等」直接复用——复用的是一个永远不会执行的僵死 watcher，所以看着像彻底没触发。这次两处修复：

1. **锁记录 watchPid、复用前查僵死**：`auto-sync.lock` 现在写入 `{pid, mode, watchPid: 当前 DSH pid, at}`。spawnWatcher 复用锁前先看 `watchPid` 是否还活着：watchPid 缺失（旧版锁）或对应 DSH 已退出 → 判定僵死，杀掉旧 watcher、清锁、重新排；只有 DSH 与 watcher 都还活着，且 mode 相同才复用。
2. **post-exit wait 段自清过期 watcher**：当 WatchPid 已退出、而进程名还有实例时，比较这批 DSH 进程的启动时间——若它们全部晚于本等待进程，说明我们等的那次 DSH 早已退出重启，本 watcher 属于上一代残留：写日志、清掉自己那把锁、`exit 3` 让位，不再死等 30 分钟霸占锁。

配套把 `post-exit.ps1` 同步进配置仓库的执行体镜像，保证走仓库兜底脚本时也是同一份修复。

### 点 × 关闭 DSH 时立即判一次自动拉取/推送（0.3.93）

勾了「启动时自动拉取」或「退出时自动推送」后，原来只有启动后的 8 秒首检 + 每 2 分钟复查会排队。如果你在两次复查之间做了改动就点右上角 × 关闭，那一刻没有 watcher 在等退出，关闭后什么都不会执行。现在补上退出钩子：点 ×（最后一个可见窗口关闭）时插件先判一次并排好 watcher，再退出客户端；DSH 进程归零后 watcher 立刻执行拉取/推送。

1. **退出前判一次**：无可见窗口时调用 `triggerAutoSyncOnClose(config)`，读 `autoPull`/`autoPush` 开关；已有在途 watcher 就复用、不重复拉起；本机仓库为空时只有 autoPull 能排队（首次 clone）。
2. **判据与复查完全一致**：拉取优先（云端领先 > 0 就排 pull，关闭时不弹确认框）；推送按「领先提交 / 未提交改动 / 本机资料比上次同步新」三来源任一命中就排 push；`autoRestart` 语义统一为 `!== false`（默认重启）。
3. **排队先于 quit**：必须在 `app.quit()` 之前 `await` 排队——插件随主进程退出而消失，quit 后再判就来不及。开关都关 / 无待同步内容时该函数很快返回，不影响关闭速度；排队成功写日志「退出前已排队 …：DSH 退出后立即执行」。

### 远端「未提交」纳入本机待同步 + 刷新按钮真正 fetch（0.3.92）

针对「远端信息还是没更新」的实测根因：git 层的「落后/领先」确实是 0（本机 HEAD 与云端 gitee 一致），用户说的「没更新」其实是本机运行期新产生、还没 capture 进仓库的待同步数据。这次做两处实质性改动：

1. **「未提交」= git 工作树改动 + 本机待同步**：后端 status 的 `repo` 对象新增 `pending`（本机还没同步的会话/配置改动数）与 `uncommitted`（`dirty + pending`）两个字段。面板两处「远端」Kv 的「未提交」改用 `uncommitted`，并在有待同步项时追加「（本机待同步 N）」。这样本机有新会话/配置改动时数字立刻可见，不用等退出 DSH capture。
2. **「刷新」按钮真正 fetch**：原来摘要行的「刷新」只重读 status（不触发 git fetch，落后/领先数照旧）。现在刷新按钮走 `refreshRemoteNow`：先 `/config-sync/auto {action:'check'}` 触发 `git fetch` 更新远端引用，再刷新快照；展开时的 30 秒自动刷新统一复用这条链。

### 设置-通用-配置同步：远端信息自动刷新 + 立即拉取/推送按钮（0.3.91）

「设置 → 通用设置 → 配置同步」摘要行两处调整：

1. **远端信息不再陈旧**：展开这一行时会先请求 `/config-sync/auto` 的 `check` 动作（触发 `git fetch` 更新 `@{upstream}`），再刷新状态，远端「落后 X · 领先 Y · 未提交 Z」显示的是云端最新值而非旧值；展开期间每 30 秒自动刷新一次，收起即停。根因是 `@{upstream}` 的落后/领先数只在 fetch 后才更新，单纯读 status 不会触发 fetch。
2. **按钮换成「立即拉取 / 立即推送」**：原来四个「生成脚本 / 只生成推送 / 只生成拉取 / 只生成还原」按钮换成两个 —— **立即拉取（会关闭 DSH）** 与 **立即推送（会关闭 DSH）**，和主面板「自动同步」卡走同一条 `pull-now` / `push-now` 队列：点击即排队、退出 DSH 后执行。按钮按后端门禁（`pullAllowed` / `pushAllowed`）置灰并给出提示（空仓库先推 / 云端为空先拉），排队中与结果都有中文反馈。原「生成脚本」入口保留在主面板，摘要行不再重复。

### 待办与跳转按钮的显示梳理（0.3.90）

面板的四处显示调整：

1. **跳转按钮跟随当前位置高亮**：顶部快捷标签现在会按滚动区里最靠上的可见分区自动高亮（主色底 + 主色字），一眼看出「现在在哪一区」；点按钮跳转也会立即点亮对应标签。
2. **待办去掉「本机数据」字眼**：原本地位等同小标题的「本机数据 / Local data」行删掉，待办卡直接以统计与明细呈现，不再重复冠名。
3. **待办可展开具体名称**：每个分组（会话记录 / 本机 profile / Skills …）一行，点它展开看该组的具体名称 —— 会话显示会话记录标题（读不到时显示 `<sessionId>（会话）`），本机 profile 显示 `package.json`、`cordis.patch.yml` 等文件名，每项按组去重、最多列 50 条。待办卡标题行有「展开 / 收起」总开关，默认展开，进来即可见明细。
4. **概览说明同步**：分区说明改为「版本、依赖、快照与待办一眼看完」。

### 本机数据挪进待办 + 按同步内容分组 + 会话显示会话名（0.3.86）

把「本机仓库」卡里的「本机数据」行移到了「概览 → 待办」，并重新组织它的呈现：

1. **位置**：原先「本机仓库」卡底部那行「本机数据」删掉；现在待办卡在无其它异常时也照样出现，顶部先显示本机数据（上次同步时间 / 待推送数 / 模式），下面才是原来的待办建议。这样「本机还有多少没推」和「该做什么」在同一处看。
2. **按同步内容分组**：待推送文件按「同步内容」那套 12 组口径归类统计 —— 会话记录 / Skills / 插件数据 / 记忆数据 / 本机 profile / 全局提示 / Agent 预设 / 插件设置 / 工作区资料 / 额外路径 等，每组一个 chip 显示条数，按数量从多到少排；不再只报一个总数。
3. **会话显示会话名**：待办里「最近写入」的样本，会话文件显示投影缓存里的会话标题（和 DSH 面板一致，如「列出工作区下的文件夹」），不再是 `session-xxx/session.v4.jsonl.zstd` 这种目录 ID；取不到标题的非会话项仍显示父目录/文件名。

### 工作区显示卡片：整卡一个「修改」按钮，会话与开关一一对应（0.3.84 / 0.3.85）

「工作区显示」卡片的编辑交互重做：

1. **整张卡片只有一个「修改」按钮**（0.3.84）：以前每个工作区行各带一个「修改 / 完成」，按钮一多就和会话对不上。现在标题行右侧只有一个按钮 —— 非编辑态是「修改」，点进去变成「完成」（主色高亮，位置不动），所有工作区的三态下拉和所有会话的显隐开关一起解锁，再点一次统一退出。行内那个按钮已删除。
2. **会话与按钮的对应关系做实**（0.3.84）：每条会话独占一行，行间加分隔线；编辑态下整行加底色 + 圆角，把「这一行会话」和「这一行按钮」框在一起。开关贴在该行最右侧且等宽，换行也不会漂到别的会话旁边。按钮文案与颜色区分「隐藏」（红）/「显示」（绿），`title` 里带会话名，隐藏的会话名加删除线并变灰（原来那个单独的「已隐藏」小字去掉了）。
3. **不额外插强调色说明条**（0.3.85）：编辑态不再在列表上方插一条黄底提示，是否在编辑只看标题行那个按钮本身。

### 工作区显示卡片：连空会话与空闲审查父容器一起折叠（0.3.83）

在 0.3.82「默认折叠智能体子会话」之外，再默认折叠两类干扰条目：

1. **空会话**：建了但从没发过消息、也没跑过 turn 的历史条目（会话头 `origin` 为空，日志里只有 permission / sandbox / approval / session-end-seed 这几条，没有 `turn/start`、没有 `user/message`）。
2. **Mnemon 空闲审查的父容器**：`mnemon-review-owner-v1-*`，它自己只有一条 `subagent/catalog` 事件，真正的内容都在它指向的 `mnemon-review-v1-*` 子会话里。

两类都天然满足「blank」判据，所以用同一条规则折掉，不需要单独写名字匹配。卡片标题行新增「显示空会话」勾选项，需要时可以放回来；footer 会分别说明折叠了多少条空会话和多少条智能体会话。本机默认视图从 99 条降到 10 条。

### 工作区显示卡片：默认折叠智能体会话 + 隐藏/显示即时生效（0.3.82）

「工作区显示」卡片两处改动：

1. **默认折叠智能体（subagent）子会话**：卡片只列你自己的会话，标题行新增「显示智能体」勾选项，需要时勾上才把智能体子会话一并列出，并显示被折叠的条数。本机 99 条登记会话里有 80 条是智能体子会话（mnemon 审查 / 派生任务都会留一条），一屏全是它们，自己的会话反而找不到。
2. **隐藏/显示即时生效**：之前切三态或单条会话只改磁盘上的状态文件，宿主内存里的 `archivedSessionIds` 不更新，必须重启客户端或刷新会话列表才看到变化。现在改走宿主的 `workspaceRegistry`（`archiveSession` / `unarchiveSession`），落盘的同时触发会话列表推送，面板上切完立刻生效。宿主服务取不到时自动退回原来的文件写法，并在卡片提示里说明走的是哪条路。

会话所属工作区与会话标题的读取仍然自包含，不依赖 session-manager 的 Web API。

### 工作区显示卡片的会话名称与 DSH 面板保持一致（0.3.81）

修复「工作区显示」卡片里会话名称与 DSH 会话面板显示不一致的问题。

DSH 的会话标题会演进：先产生 fallback 临时标题（首条消息截断），随后由大模型生成 provider 正式标题。之前卡片只读到第一条 fallback 就停止；现在改为按 provider 正式标题 > fallback > 无来源 title > 首条用户消息 的优先级取最新标题，与 DSH 面板完全一致。
### 修复跨机同步把新插件降级覆盖、拉取后被回滚（0.3.80）

修复跨机拉取时本地已安装的新版插件被配置仓库里的旧归档反向覆盖，进而导致 link 变成 0.0.0、插件 bundle 自检失败、拉取自动回滚的问题。

| 问题 | 修复 |
|---|---|
| 归档版本比本机旧时仍被当作新版本覆盖 | 版本比对由「不等即覆盖」改为语义化「只升不降」：只有归档版本高于本机版本才重新部署 |
| 归档内顶层目录名与文件名不符（如 0.3.70 包里套着 0.3.56 目录），解压出嵌套目录导致 link 失效 | capture 打包后强校验归档内顶层目录名与 version，异常归档直接删除并告警，不再同步到本机 |
| 残留的旧插件键导致每次拉取报 plugin-missing | 清理 localPluginMap 中的无效历史键与历史通知 |

同时修正配置仓库中损坏的插件归档，用正确的 0.3.79 内容重打包。

### 面板改成「页头固定 + 内容区独立滚动」的两段式布局（0.3.79）

0.3.78 仍是一个滚动容器里塞一个吸顶页头，遇到两种情况还是会露：面板变矮、或页头换行变高时，内容会擦着标题分隔线上沿过去，甚至从标题上方那圈留白里露出来；跳转落点按页头高度动态算，条件分区出现/消失时也会忽高忽低。

0.3.79 换成两段式：页头（标题 + 徽标 + 元信息 + 区标签）**整体移出滚动区**，固定在面板顶部；下方另起一块带 `overflow-y:auto` 的内容区，只装提示条和各分区卡片。带来三个直接效果：

1. **结构上不可能再穿过去**：内容区边界就在标题分隔线下方 20px，滚动再多也只在内容区里，不会出现在标题区或标题上方。
2. **跳转落点固定**：区标签跳转直接滚到内容区顶部 + 8px，不再按页头高度算偏移，页头怎么换行、条件分区在不在都不影响。
3. **页头不再抖动**：页头不参与滚动，滚动条、阴影、半透明背景那套补丁全部去掉，只留一条分隔线。

改造只动面板自己（`S.page` / `pageInner` 只在这一处用），侧栏行、设置页摘要行不受影响。


## 同步后新会话落在默认工作区

`<DshHome>\storages\workspace.json` 的 `global.defaultWorkspaceId` 决定新会话落在哪。DSH 只在本机**首次初始化**写过一次，之后同步几轮就可能停在「上次用的工作区」。`post-exit.ps1` 在**客户端完全退出之后、重新拉起之前**把它校正到默认工作区（早写会被客户端退出时的回写盖掉）。

| 项 | 说明 |
|---|---|
| 默认行为 | 找标题为 `default-workspace`、或路径以 `\deepseek-harness\default-workspace` 结尾的工作区 |
| 指定别的 | `~\.dsh\dsh-config-sync.json` 的 `defaultWorkspace` 填工作区 ID 或绝对路径 |
| 关掉 | 同一字段填 `off`（或 `none`） |
| 安全阀 | 值不同才写；写前备份 `workspace.json.bak-<时间戳>`；写完回读校验；匹配不到就不动 |
| 副作用 | 你手动切换的「默认工作区」会被下一次同步覆盖回来——不想要就设 `off` |

## 退出后执行的三套动作

推送 / 拉取 / 还原统一走「点按钮排队 → DSH 退出 → `post-exit.ps1` 自动执行 → 重启」，不再生成需要手动双击的 `.cmd` 脚本。执行体本身仍在 `runtime/`：

| 动作 | 干什么 | 安全阀 |
|---|---|---|
| 推送（`sync.ps1 push`） | 退出后 capture 并推到远端 | 本机仓库是空目录/云端已有内容时按门禁拒绝 |
| 拉取（`sync.ps1 pull`） | 退出后拉取并 apply | 拉取前检查 scope/根路径/link 前置条件；失败自动回滚 |
| 还原（`restore.ps1`） | 退出后把 profile 退回某次 apply 前的快照 | 先 `-DryRun` 打印计划，确认差异后才排队 |

`sync.ps1` / `restore.ps1` 支持 `-Yes` 免确认（退出后自动执行路径使用）。还原时若已有快照会用 `-BackupDir` 明确指定；没有则交给 `restore.ps1` 运行时取最新一份（最新是空快照时自动往前找第一份含 `package.json` 的）。

## 同步冲突

拉取被本机文件挡住（同路径两边内容不同）时 git 会整批 `Aborting`。旧做法是失败就 `reset --hard` + 用快照还原配置，实测会把**已快进成功**的 HEAD 又打回旧提交，于是永远差几个提交。现在的做法**不 reset**：

1. `sync.ps1 pull` 先 `git fetch`，判定能否快进，再算交集：`git diff --name-only HEAD origin/x` ∩（本机未入库 ∪ 本机已修改）。命中就**逐文件两边都备份**、写 `~\.dsh\sync-conflicts.json`，然后 `exit 6` 停下，**仓库与配置都不动、HEAD 不回滚**。
   备份在 `~\.dsh\backups\conflict-<时间>-拉取冲突-Pull-conflict\`：`本机-Local\<路径>`、`云端-Cloud\<路径>`（`git cat-file blob` 按字节落盘，二进制不转码）、`说明-README.txt`、`清单-Conflicts.json`。任一侧字节数与源文件对不上就标未备份、面板对应按钮置灰。
2. 重启客户端后面板出现「同步冲突」卡：一行一个文件，点整行展开两侧预览；每行「用本机 / 用云端」，底部「全部用本机 / 全部用云端」；展开后还能「还原本机副本」「还原云端副本」（两份都能单独写回，不动 git 历史）。
3. 选完点「立即拉取」：`用云端` 的删掉工作区副本、`用本机` 的也先删（让 git 能快进），快进后再把 `用本机` 的从备份写回，于是变成一次本地改动，下次推送带上。

粒度只有「逐项 用本机 / 用云端」＋「单项从备份还原」，不做预览内编辑或手工合并。

接口：`GET/POST /config-sync/conflict`（GET 读清单，每项带 `localSaved`/`cloudSaved`；POST `{items:[{path,choice}]}` 存选择、`{action:'restore',path,side}` 单项还原、`{action:'reset'}` 放弃清单）。还原按清单里记录的 `repo` 路径写，改过 `repoPath` 也不会写错仓库。

## 还原备份

面板「还原备份」卡（排在「自动化与插件更新」之后、「同步内容」之前）：上面一行是备份目录（默认 `~\.dsh\backups`，`apply.ps1` 每次拉取/落地前都会打一份快照），下面列出该目录下所有快照——名称、时间（带「3 分钟前」）、插件数、能否还原。

- **列表不显示体积**：每份快照是整份 profile（几千文件），旧版每次刷新都逐个 `stat`，92 份 / 4.8 万文件实测 7.7 秒，`/status` 拖到 11 秒、前端 fetch 撑不住就显示「读取失败」。现在只给名称/时间/插件数/是否可还原；远端探测改成「缓存 5 分钟 + 每次最多等 2.5 秒 + 装载时预热」，前端 status 带 15 秒超时和 3 次自动重试。实测 status 8.0 秒 → 0.35 秒（中位，20 次）。
- **「立即还原」是个流程**：点某行 → 宿主取**差异预览**（撤走哪些插件、移走哪些新增文件、覆盖哪些文件、要重装什么）→ 「确认还原」才排队 → 客户端正常退出 → `post-exit.ps1` 弹可见进度窗口跑 `restore.ps1 -RollbackToPoint` → 结果写 `auto-sync-result.json` → 自动重启。不用自己退客户端、输 `y`。
- **时点还原 = 回到那个时间点**：快照之后新增的文件移进 `backups\manual-<时间戳>\rollback\files`；之后装上的插件，junction 只删链接（不穿进链接删实体）、实体目录移进 `rollback\plugins`；每项写进 `rollback\rollback-manifest.json`，全部可再还原。动手前先把当前配置另存 `manual-<时间戳>`。
- **谁算「快照之后装上的插件」**：以还原后 `package.json` 的 `dependencies` 为准，`node_modules` 里不在其中的直接子目录（含 `@scope/包`）撤走。
- **地址可自己改**：点「修改」填绝对路径（如 `D:\DSH备份`），存在 `~\.dsh\dsh-config-sync.json` 的 `backupRoot`；「恢复默认」清回 `~\.dsh\backups`。
- **三类备份各有还原入口（0.3.49 起）**：备份根 `~\.dsh\backups` 是多用途共用的，面板按内容分成三类，每类都能一键还原：
  - **配置快照**（`config-*` / `manual-*`，顶层 `package.json` 且 `name: dsh-profile-*`）→「立即还原」，做时点回退。
  - **插件备份**（`plugin-<版本>-*`，含 `runtime\` / `client.js` 或只有一层 `dsh-config-sync-<版本>\`）→「回滚插件」：先把当前插件整份备份成 `plugin-<当前版本>-<时间戳>`，再用目录合并复制写回插件安装目录（`Copy-Tree` 逐层合并，不会出现 `runtime\runtime`；这点 0.3.49 实测踩过）。
  - **会话备份**（`session-corrupt-*`，顶层全是 `--<路径编码>--`）→「还原会话」：把会话目录写回 `~\.dsh\sessions`，同名目录先整份留底到 `backups\session-<时间戳>`。
  - **认不出类型的**（冲突对照、手工拷来的）→「手动还原」：弹出备份路径、里面有什么、以及三类常见目标位置，按提示手动拷；不再有「不可还原」的死按钮。
- **分类判据不能只看有没有 `package.json`**：profile 的 `package.json` 里**也有** `dsh` 字段（`dsh.profile.bundles`），拿 `dsh` 判插件会把整份配置快照误判成插件备份（实测 `config-*`/`manual-*` 8+2 份全中招）。现在顺序是：`name: dsh-profile-*` 或 `dsh.profile` → 配置；`name: dsh-config-sync` → 插件；再按顶层内容和目录名前缀兜底。空目录（半截安装残留）标「空备份」不给按钮。
- **只认能用的快照**：配置快照没有 `profile\package.json` 的（新机器首次拉取时本机无配置可备份）标「空备份」置灰；宿主 `restore-backup` / `restore-preview` / `restore-now` 共用 `resolveSnapshotDir` 同一套校验，认不出类型会直接拒绝并提示走手动还原。
- **只在这个目录里选**：面板传来的必须是备份根之下真实存在的一份快照（越界、相对路径、含引号换行直接报错）。

## 插件配置跟得走

新机器同步完发现「配置没了」，多数不是拉取失败，而是**这些配置从来没进过仓库**。插件配置组覆盖 13 项：

| 仓库路径 | 本机来源 |
|---|---|
| `settings\our-free-model.json` | `~\our-free-model\settings.json`（运行时字段已归一，不会每轮都「有改动」） |
| `settings\comfyui-workflows.json` | `~\data\dsh-comfyui\workflows.json` |
| `settings\dsh-pet-main-config.jsonc` | `~\dsh-pet\main-config.jsonc` |
| `settings\dsh-pet-memory.json` | `~\dsh-pet\memory.json` |
| `settings\dsh-market-state.json` | profile 下 `.dsh-market\state.json` |
| `settings\our-free-model-picks.json` | `~\our-free-model\picks.json` |
| `settings\dsh-im-interface-language.json` | `~\integrations\dsh-im\interface-language.json` |
| `settings\dsh-qq-config.json` / `dsh-qq-workspaces.json` | `~\integrations\dsh-qq\config.json` / `workspaces.json` |
| `settings\redteam-preset-declare.json` | `~\redteam\preset-declare.json` |
| `settings\task-board-ledger.json` / `task-board-scheduler.json` | `~\task-board\ledger-v2.json` / `scheduler-v2.json` |
| `settings\dsh-workspaces.json` | `~\storages\workspace.json`（新机器「工作区不见了」就是它没同步） |

**这是白名单，不是整份搬**：`~\.dsh\settings.json` 本身不进仓库，自由格式的自定义键会被丢弃（隔离实测确认过）。**排除**：凭据与运行时状态——`channel-pack`（含 `token-ledger.json`）、`workbuddy-vault`、`dsh-purge`、`stats`/`feed`/`catalog`/`availability`、`integrations\dsh-qq\bots\<bot>\state.json`、会话缓存。

### 带本机路径的配置：占位符 + 换机确认

| 占位符 | 含义 |
|---|---|
| `{{APP_ROOT}}` | 客户端安装目录 |
| `{{DSH_HOME}}` | `.dsh` 配置目录（一般 `%USERPROFILE%\.dsh`） |
| `{{WORKSPACE_HOME}}` | 工作区根目录 |
| `{{ROOT:<key>}}` | 用户自选目录（ComfyUI 模型目录、代理路径等），键值在面板里定 |

- `capture.ps1` 写仓库**前**归一：本机根 → 占位符。同一路径的 4 种写法（原生反斜杠 / JSON 双反斜杠 / 正斜杠 / JSON 转义斜杠）都认；替换按根长度降序（工作区根在安装目录之下，先换长的才不错位）。
- 仓库里一律**正斜杠**（`{{APP_ROOT}}/mnemon`），避开 JSON 反斜杠转义。
- `apply.ps1` 落地**前**展开：占位符 → 本机路径。

### 路径确认：拉取后由你选，选过就不再问

- 首次同步在 `~\.dsh\config-sync-roots.json` 落一份本机根（探测值），本机私有、不进仓库。
- 某机器缺某个根（展开不掉）时，`apply.ps1` **跳过那个文件不写**，记进 `~\.dsh\config-sync-pending-paths.json`。
- 面板「本机路径」卡列出这些项，填好本机路径 → 保存 → 重新拉取一次就写进去；确认值优先于自动探测，之后不再问。**宁可不写**，也不把 `{{ROOT:xxx}}` 字面量写进配置。

### 两条体检

**推送之后（capture 末尾）**：扫仓库里的**配置类文件**（`settings\*.json`、`profile\*.json`、`skills\`、`presets\`、`prompt\`、顶层 json；`conversations/workspace/mnemon/storages-record` 是会话与运行时数据，换机器本来就不该一致，不参与），把**不属于任何已确认根**的绝对路径抓出来，写 `~\.dsh\config-sync-absolute-paths.json`（带 `machine` 与写它时各根的值），控制台 `Warn` 一句。**不拦提交**。

**这份清单只对「接收方」有意义**（0.3.43）：清单是推送时写的，本机推出去的路径在本机当然都在，摊在本机面板上只会让人以为出了问题（实测 50 条里有 40 多条是 `conversations\session_projcache` 的会话缓存）。现在面板先比清单里的 `machine` 与本机机器名：

- **清单来自本机** → 不显示、不计入告警数（`status.localPaths.absolute` 归 0）。
- **清单来自另一台机器**（本机是接收方，刚要拉或刚拉完）→ 显示「这份配置是 `<机器名>` 推送的」，并**逐条给推荐目录**：先拿报告里记着的对方根值做前缀映射（`F:\DSH\SquadLink` → 本机 `<APP_ROOT>\SquadLink`，保留原大小写）；没有根可映射就按最后一级目录名在本机几个根、用户主目录、桌面、各盘根下找同名目录；都没有就明说「本机没有等价目录」。
- 每行一个「采纳」：点一下把推荐目录记进本机自选目录（`{{ROOT:<key>}}`），下次推送起这些路径变成占位符，哪台机器拉取都换回自己的值；已采纳的行显示「已采纳」。
- 顺带过滤正则误匹配：`s://1v3.apiipu.com/...` 以前被当成 `s:` 盘符，现在含 `://` 直接跳过。

**拉取之前（apply 写 settings 前）**：铺配置是整份 `WriteAllText` 覆盖，改完路径没推送就点拉取，改动会被静默盖回去。所以覆盖前先比一次：本机现状（归一化成占位符、CRLF 拉平成 LF、`our-free-model.json` 的 `catalogSyncedAt/reloadedAt/reloadCount` 一起置 0）与仓库版本不一样，就记进 `~\.dsh\config-sync-overwrite.json`，面板提示「有 N 份配置被仓库版本覆盖（本机改动已先备份）」。想保住本机改动：**先推送，再拉取**。

### 「本机路径」卡怎么用

- **平时整块不渲染**，入口只有标题行的「本机路径」按钮。
- **三类都算告警**：待确认路径、仓库里有根外绝对路径、上次拉取覆盖了本机配置——`status.localPaths.alert` 给合计，按钮变橙显示「本机路径 · N 项告警」。
- **默认只读**：三行根用等宽字显示当前值与对应占位符；自选目录同样展示。点「修改」才变输入框。
- 编辑态多三件事：每个根右边「用探测值」；每个自选目录右边「删除」；底部「新增目录」填键名 + 路径（键名只接受字母数字 `_ . -`）。
- 这一卡的值**优先级最高**：保存过的根压过脚本探测值（`Get-SyncRoots` 里 roots.json 优先、只补空值）。填错不是"没生效"，而是真的按错值展开成死路径。

## 问题反馈：走 GitHub Issue

**GitHub Issue 是唯一真源**，不再往配置仓库塞 json：

1. 填标题 + 详情 → `POST /repos/QcWyGm/dsh-config-sync-plugin/issues`，label `feedback`，正文末尾自动附环境块（插件版本、机器名、时间、平台、安装目录、配置仓库路径）。
2. 列表直接读 Issue（`state=all&labels=feedback`），点标题去 GitHub 网页。
3. 点「已解决」→ `PATCH issue {state:'closed'}`。
4. 顶上一行连接状态三态：`已用 xxx 登录` / `令牌不属于所有者（只能读和提交）` / `匿名读取（提交走浏览器）`。

- **读不需要令牌**：仓库公开，匿名请求能读（60 次/小时·每 IP）；有令牌才走 5000 次/小时。
- **没令牌也能提交**：把标题、正文、环境块预填进 GitHub 新建 Issue 页面，浏览器里登录着的话点 Submit 即可。
- **关单只有仓库所有者能点**：先 `GET /user` 认令牌归属，`login` 与仓库所有者不一致就 403。
- **令牌不用手填**：默认从本机 git 凭据 `git credential fill` 取一次，存 `<dshHome>\config-sync-gh.json`（本机私有、不进仓库）；取不到才需要粘一次，粘完立刻用 `/repos/{repo}` 验一遍。
- **断网不丢**：建 Issue 失败进 `config-sync-feedback-outbox.json`，联网后点「补发」逐条建，成功的自动出队。
- 列表头上「未解决 / 已解决 / 全部」+ 搜索框（编号、标题、作者、正文、环境块都参与），筛选全在本地做，不占匿名限额。

## 卸载残留自动清理

宿主卸载插件时**不删 `profile\node_modules` 里那条 junction**。`apply.ps1` 每次落地巡检一遍，只删**三条同时成立**的链接：①`LinkType` 是 Junction/SymbolicLink；②所有 Target 都不存在；③不在 `package.json` 的 `dependencies` 里。用 `Directory.Delete` 只删链接本身、不顺着链接动目标。

**顺手清插件备份**：与在用版本**相同**的 `.bak-<时间戳>` 直接删；版本不同的只留最新一份；主目录已不存在的备份保留（可能是唯一回滚点）。部署判据比归档内 `package.json` 的 version 与已部署目录的 version（之前比 mtime，被 `git checkout` 刷时间害得每轮误判「有新版本」）。

## 同步内容勾选

面板最下面「同步内容」卡，十二组逐组列出、**默认全勾**；点一行展开明细，组和单项都能取消勾选——取消后**推送不再抓、拉取不再还原**，重新勾上继续同步（推拉共用同一份勾选）。

| 组 | 云端目录 | 明细项 |
|---|---|---|
| 本机 profile | `profile/` | package.json / lock / cordis 等（整组开关，**必需不可取消**） |
| 提示词 | `prompt/` | `AGENTS.md`、`prompt-inject.md` |
| 技能 | `skills/` | 每个技能目录 |
| 预设 | `presets/` | 每个预设 |
| 技能市场台账 | `storages-record/` | 两个台账 json |
| 插件配置 | `settings/` | 13 个文件，可单独排除 |
| 记忆 | `mnemon/` | 整目录 |
| 本地插件 | `local-plugins/` | 每个 link 插件 |
| 插件数据 | `plugin-data/` | 每个插件自己的一级目录（自动枚举，见下节） |
| 额外路径 | `extra/` | 你自己加的绝对路径（见下节） |
| 工作区 | `workspace/` | 每个登记的工作区 |
| 会话 | `conversations/` | 每个工作区对应的会话 |

- 先只读，点「修改」才解锁勾选，改完「保存」才写文件。
- 勾选记在 `~\.dsh\config-sync-scope.json`，跟本机走、不进仓库；只留与默认不同的项，删掉就恢复全勾。
- 跳过**两侧都生效**：`capture.ps1` 不抓、`apply.ps1` 不还原；`-PruneSkills` 也不会把"勾掉的本机技能"当多出来的项删掉。
- 另有开关「取消勾选时顺手删掉云端副本」，**默认关**；打开后取消勾选会真的删仓库里的对应目录（删除不可恢复）。
- **`本机 profile` 是必需内容**：仓库里没有 `profile\package.json` 或 `cordis.patch.yml` 时拉取会 `[X] 仓库内容不完整` 退出；`profile\host-contract.json` 自 0.4.10 起只用于「本机/契约」信息条展示，版本不同不再阻断拉取。

## 插件数据与额外路径（0.3.51）

新装的第三方插件，配置和数据多半写在自己的一级目录里（`~\.dsh\<插件名>\`）。这两组把它们也带上：

- **插件数据（`plugin-data/`）**：自动枚举 `<DshHome>` 的一级目录，一个目录一个槽，收成 `plugin-data\<槽名>\...` + `plugin-data\manifest.json`（`slots[{id,src,files,bytes}]`）。
  - 默认跳过：`profiles`、`skills`、`.agent-presets`、`storages`、`sessions`、`attachments`、`logs`、`backups`、`update-staging`、`electron`、`dsh-runtimes`、`dsh-market`、`.dsh-plugin-market`、`dsh-session-manager`、`im`、`node_modules` 和隐藏目录——这些要么已经有专门的组，要么是缓存/运行时。
  - 每个槽最多扫 8 层、4000 个文件（防止某个插件把整仓库塞进来）。
- **额外路径（`extra/`）**：面板里自己加的绝对路径，目录或单个文件都行；落成 `extra\<id>\...` 或 `extra\<id><扩展名>` + `extra\manifest.json`。
- **文本做占位符归一，二进制字节保真**：文本文件里的 `{{APP_ROOT}}` / `{{DSH_HOME}}` / `{{WORKSPACE_HOME}}` / `{{ROOT:x}}` 由 `ConvertTo-TokenText` 写进仓库（顺带 CRLF→LF），换机 apply 时用 `Expand-TokenText` 展开；`.db`/`.node`/`.exe`/图片这类二进制（或含 NUL 字节的文件）原样字节拷贝。
- **写回先留底**：apply 逐文件合并，目标侧被覆盖的旧文件先备份到 `backups\config-<时间戳>\plugin-data-<槽>` 或 `extra-<id>`。

### 规则文件：`~\.dsh\config-sync-extra.json`（本机，不进仓库）

面板上「插件数据与额外路径」卡直接改这份文件：

| 字段 | 含义 |
|---|---|
| `pluginData.enabled` | 插件数据整组开关（与「同步内容」里那一行联动） |
| `pluginData.maxFileBytes` | 单文件上限，**硬顶 104857600（100MB，GitHub 单文件硬限）**，填大了也按 100MB 算 |
| `pluginData.exclude` | 排除名单，通配、一行一条，**整份替换**（清空就真的不排除任何文件） |
| `pluginData.skipDirs` | 自动枚举时跳过的一级目录名，同样整份替换 |
| `extra.enabled` / `extra.paths[]` | 额外路径整组开关与路径清单（`{id,src,label}`，src 必须绝对路径） |

默认排除名单（50 条，可按需删改）：`*.db` / `*.db-*` / `*.sqlite*` / `*.db-shm` / `*.db-wal`、`*.node` / `*.exe` / `*.dll` / `*.asar` / `*.pak` / `*.bin` / `*.img` / `*.iso`、压缩包 `*.zip|7z|rar|tar|gz|tgz`、`*.mp4|mkv|avi`、`*.log` / `*.log.*`、`*.tmp` / `*.bak` / `*.bak-*` / `*.old` / `*.orig` / `*.swp`、`api-key` / `*.pem|key|p12|pfx|crt`、`*cache*` / `*token*` / `*secret*` / `*credential*` / `*password*`、`*vault*`、`node_modules` / `.git` / `.cache` / `__pycache__` / `.venv`。

- **为什么默认排掉缓存/令牌/数据库**：`*cache*`、`*token*` 这类「每次运行都变」的文件会让每次推送都有 diff；`.db` 常被插件自己锁着写，跨机器还原容易坏。
- **额外路径放标准根下更稳**：在 `~\.dsh\`、客户端目录、工作区根之下会被归一成占位符；放在别处（如 `D:\tmp\xxx`）只能按同一个绝对路径铺，对方机器没这个路径就跳过并 `[!]` 提示。
- 清单里的路径若展开后仍有未配置的占位符，apply 跳过该槽并 `[!]` 提示，不会把 `{{DSH_HOME}}` 原样写进插件配置。

## 自动同步 / 自动推送（默认关）

| 开关 | 行为 |
|---|---|
| 启动时自动拉取 | 启动 8 秒后只读 `git fetch` 比对；落后 > 0 → 系统确认框 → 选"是"**当场把客户端整族退出**（实测 5 秒内进程归零）→ 可见窗口跑拉取 → 拉完自动重启。手动点 × 关闭时也会判一次并排队（0.3.93，关闭场景不弹确认框，云端领先就排） |
| 退出时自动推送 | **三个来源任意命中就排队**：本地领先提交、未提交改动、本机资料比上次同步新（新会话等）。启动后每 2 分钟复查，点 × 关闭时也会立即判一次（0.3.93），已排队不重复拉起；等 DSH 完全退出后才 push，推完自动重启 |

- 动手由插件拉起 `runtime\post-exit.ps1 -Phase wait`（**隐藏**）盯退出；真退了才用 `-WindowStyle Normal` 起 `-Phase run` 的**可见**窗口，标题「DSH 配置同步 · 拉取/推送」。**排队期间不弹窗**。
- 仓库还没就位（含空目录）时首检直接跳过，且不记成"检查失败"。
- **拉起方式**：`detached: true` 起 powershell 在 Windows 上会当场退出（日志一行都没有），改成短命 powershell 用 `Start-Process -PassThru` 起独立进程；`spawn()` 失败是异步的，所以要等 launcher 退出码、拿不到 pid 就如实失败，并写 `~\.dsh\logs\auto-sync-launch.log`。
- **等退出不能只看 pid**（插件跑在子进程里）：改成按进程名。0.4.06 起「点了关闭但进程赖着不走」改由**可见窗口**判定：见过窗口之后连续 3 拍归零就结束残留进程开工；旧的「活过 60 秒、无可见窗口持续 16 秒」只保留给「窗口在 watcher 启动前就关了」这一种兜底。
- **点 × 由后端窗口监视识别，不靠浏览器**（0.4.06）：常驻采样进程每 250ms 报一次 DeepSeek Harness 的可见窗口数；「见过窗口 + 连续 4 拍归零（约 1 秒）」就是用户在关窗。此时判一次 drift、排好 watcher，**只有确有活要干**才强杀残留进程族；没有待同步内容就让客户端正常退出（不跳过落盘）。前端 `pagehide → sendBeacon` 信标与 0.4.05 的 2 分钟预排都保留作双保险。两个开关仍需勾选。
- **一个时刻只跑一次同步**：`~\.dsh\auto-sync.lock` 记 pid，后来者读锁（同种复用，不同种先结束那个没开工的等待进程再改排）。
- **退出客户端用整族结束**：`taskkill /PID` 不带 `/F` 对 Electron 主进程无效，改 `/IM "DeepSeek Harness.exe"`，3.5 秒后再补 `/F`。
- **重启前清环境变量**：继承的 `ELECTRON_RUN_AS_NODE` / `ELECTRON_NO_ATTACH_CONSOLE` / `NODE_OPTIONS` / `NODE_PATH` 会让客户端"起来就退"，清掉后一次成功；启动后数进程、没活等 8 秒重试，最多 3 次。
- **拉取失败自动回滚**：`git reset --hard` 回原提交 → 用这次 apply 写盘前刚建的 `backups\config-<时间戳>` 跑 `restore.ps1` → 结果写日志。
- **进度窗口收尾**：跑完不自动关闭，把「同步已完成 / 日志路径」留在屏幕上，按键或点 × 才退出。客户端是**在这之前**由 `explorer.exe` 代启的，没有父子关系，窗口留多久都不会带走客户端。
- 退出码：`0` 完成、`2` 等待超时、`3` 缺 sync.ps1、`4` 重启失败、`5` 同步失败（pull 已尝试回滚）。

## 插件自更新

面板「插件更新」卡显示本地版本、云端版本和一行状态；清单与安装包都在公开仓库（`version.json` + `releases/dsh-config-sync-plugin-<版本>.tgz`，只读几百字节，不拉整包），服务端缓存 30 分钟，挂载时查一次、之后每 30 分钟复查。

| 状态 | 含义 |
|---|---|
| 绿色「已是最新」 | 本地版本 ≥ 清单版本 |
| 橙色「有新版本 x.y.z」 | 清单版本更大，附说明和「下载更新」按钮 |
| 橙色「已下载，待安装」 | 包已下到 `~\.dsh\update-staging\`（插件目录一字节没改），点「重启并安装」生效 |
| 橙色「已安装，待重启」 | 老路径上（运行中安装过但没重启） |
| 红色「检查失败」 | 清单读不到，附「检查更新」逐个列出每个源的失败原因 |

- **清单多源按顺序试**：`gh-proxy.com` → `ghfast.top` → GitHub raw（国内直连 raw 常不通，而宿主 `fetch` 是 Node 内置实现、**不读系统代理**）。下载安装包按「读到清单的那个源 → 其余源」依次试。单次 30 秒超时。
- **别拿 jsDelivr 当清单源**：它对 `@main` 这类分支别名缓存很久，实测发版后仍返回上一版，让「有新版本」晚几个小时才出现。
- **私有库要填令牌**：更新相关配置都在「插件更新」卡里；填了令牌后清单与包改走 Gitee API raw 端点（`?ref=main&access_token=…`，分支用 `ref` 传、不能写进路径）；令牌只存本机，不进仓库，留空保存=不改动已存令牌，另给「清除已存令牌」。
- **下载与安装分开**：点「下载更新」只把包下到 `update-staging` 并校验 sha256，宿主不碰插件目录（页面不会跳走）；下载完按钮变「重启并安装」，点它才退出 → 备份旧目录（`~\.dsh\backups\plugin-<旧版本>-<时间>`）→ 覆盖安装 → 自动拉起，全程只重启一次。
- 为什么不再运行中安装：0.3.4–0.3.6 是「DSH 不退出直接覆盖插件目录」，实测会让宿主把当前面板卸载掉（用户看到"更新到一半页面自己跳走了"）。`POST {action:'install-live'}` 仍留给 CLI，界面不再用。

## 作为插件市场的索引源

仓库根的 `market-index.json` 就是一份可直接用的 DSH 市场索引（`format: 1`，`source.type: git` + 40 位 commit）。索引地址：

```
https://raw.githubusercontent.com/QcWyGm/dsh-config-sync-plugin/main/market-index.json
```

在 DSH「插件 → 发现 → 索引源」填入即可。**前提**：这是宿主官方发现页（`@deepseek-ai/dsh-plugin-market`）的索引源，需要 profile 启用官方 `@deepseek-ai/dsh-experimental-plugin-market-bundle`。

**dshmarket 里搜不到自建索引，是正常的**：dshmarket 的列表只来自它自己的精选目录（`awesome-dsh-plugin.com/plugins.json`，国内走 npm 的 `dsh-plugin-catalog`），源码里没有自定义索引源这条路，安装也被限定在「该目录列出的来源」。要出现在那里，只能向 [awesome-dsh-plugin](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin) 提 PR 收录。

> **收录后的可见性**（2026-11-13 实测）：PR `#14762` 已 MERGED，条目 `data/plugins/QcWyGm__dsh-config-sync.yml` 已进站点正本（`plugins.json`，`updated: 2026-11-13`，10974 条，含 `QcWyGm/dsh-config-sync-plugin`）。但客户端取源顺序是「站点正本 → 地区 npm 源 → jsDelivr 兜底」：13.8 MB 正本下载超时后落到 jsDelivr 镜像，而镜像（`dsh-plugin-catalog` npm 包每天 UTC 05:19 重建一次）还停在 `2026-11-12` / 10778 条、**不含** QcWyGm。所以「收录完了却搜不到」＝**镜像滞后**，不是代码问题；等当天目录包重建 + 缓存失效，或重启客户端让它重读，就会出来。用 CLI 强制刷新可立刻验证：

```powershell
node ~\.dsh\.dsh-plugin-market\market-core.mjs catalog --profile desktop
# ok=true, source=official, fromCache=false, version=2026-11-13, count=10974
```

> 同名冲突提醒：目录里 `dsh-config-sync` 有两条——`QcWyGm`（`github:QcWyGm/dsh-config-sync-plugin`，category git）与 `bxzfxl`（`@liangfengqi/dsh-config-sync`，category tools，downloads 843），搜索时会并排出现。

升级流程：改代码 → `pwsh -File tools\pack-plugin.ps1` 打包（自动把 sha256 回填 `version.json`）→ 改 `version.json` 的 `version` / `notes` → 把 `market-index.json` 里那条的 `version` 与 `commit` 换成新提交 → 推送。索引只引用 commit，旧版本随时能装回。打完包先跑 `node tools\selftest.mjs <仓库路径>` + `node tools\clientcheck.mjs`。

## 接口与路径

| 接口 | 说明 |
|---|---|
| `GET /config-sync/status` | 体检 JSON（`repo.*`（`source/configured/phase/empty/remoteHeads/remoteFiles/pushAllowed/pullAllowed`）、`remote.*`、`backup.*`、`local.{lastSyncAt,pending}`、`auto.lastResult`、`conflicts`、`localPaths`） |
| `POST /config-sync/settings` | 校验 → 写设置 →（地址变了才动 git），失败回滚并 400 |
| `POST /config-sync/auto` | `{action:'check'\|'pull-now'\|'push-now'\|'restore-preview'\|'restore-now'\|'cancel'}`，都不带 `/F` 关闭客户端（走正常退出，配置能存下来） |
| `GET/POST /config-sync/update` | `{action:'check'\|'install-live'\|'restart'\|'apply'}` |
| `GET/POST /config-sync/scope` | 十二组同步范围读写 |
| `GET/POST /config-sync/extra-config` | 插件数据与额外路径的规则读写（`{config:{pluginData:{enabled,maxFileBytes,exclude,skipDirs},extra:{enabled,paths[]}}}`，id 去重、路径必须绝对、上限按 100MB 压；GET 另带 `defaults` 供「恢复默认」） |
| `GET/POST /config-sync/conflict` | 冲突清单与选择 |

跨站请求 403。客户端只 `fetch` 这几条，不 import 任何 `@deepseek-ai/dsh-client-*`，样式只用 `--dsw-alias-*` token。

路径：仓库按上面的优先级；客户端根 `config.appRoot` 优先，留空由插件自身位置推出，换机不用改；`.dsh` 为 `config.dshHome` → `%DSH_HOME%` → `~\.dsh`。本机私有文件：`config-sync-roots.json`、`config-sync-pending-paths.json`、`config-sync-absolute-paths.json`、`config-sync-overwrite.json`、`config-sync-scope.json`、`config-sync-extra.json`、`config-sync-state.json`。

**边界**：`capture` 要读 `cordis.patch.yml`，DSH 运行时这文件正被应用持有，抓到的是半截状态；`apply` 写完以后，DSH 退出时又会回写覆盖。所以边界固定为：判断该跑什么、把命令写好，退出 DSH 后执行。

## 生成器里已经堵掉的坑

新机器真跑一遍才暴露的坑：

| 坑 | 处理 |
|---|---|
| cmd 的 `echo` 吃 `< > \| & ^ %` | 动态文案全过 `echoSafe()`：`%`→`%%`，特殊符号前加 `^` |
| `chcp 65001` 后 `set /p` 读不到重定向输入 | `--yes` 免确认 + 无确认时明确回执 |
| 新机器分支没有 upstream，`git pull --ff-only` 报 *no tracking information*，PS 5.1 包成 NativeCommandError 后继续走 | 先探 upstream；0.3.54 起拉取改成 `fetch` + `merge --ff-only origin/<branch>`（一次网络往返），没有 upstream 就补 `set-upstream-to`；push 带 `-u` |
| `GIT_SSH_COMMAND` 少了 ssh.exe 本体 → `/usr/bin/sh: - : invalid option` | 四分支：有 `core.sshCommand` 照用；找到 `ssh.exe` 写完整命令；只有私钥就不设变量；无私钥交给 `.ssh\config` |
| 客户端 asar 打包时按路径找 AppRoot 全落空、bundle 全误报缺失 | `isAppRoot` 认 `app\package.json` **或** `app.asar`；版本与 bundle 从 asar 定向取（PS 5.1 `ConvertFrom-Json` 2 MB 上限，5.7 MB 头只能按 entry 偏移直读），判不了就当"不知道" |
| 插件目录已存在就跳过部署，tgz 更新了本机还是旧代码 | 比归档内 `package.json` version 与已部署目录 version（之前比 mtime，被 `git checkout` 刷时间害得每轮误判） |
| 开了"退出时自动推送"却什么都不发生 | 两个叠因：①排队判据只看 `ahead > 0` → 改成三个来源都算 + 每 2 分钟复查；②`spawn` 假成功 → 改 `Start-Process` + 等退出码 + 写日志 |
| 空目录被当成"仓库坏了"，推送按钮可点但必失败 | 按 `repo.phase` 分四态，三层都拦住 |
| 「云端有没有东西可拉」看分支数 → 树被删空了仍判「有内容」，初始化推送入口永不出现（实测 Gitee 98 个提交、最新树 0 文件） | 判据换成**分支树里的文件数**：`ls-remote --heads` 数分支，有分支才临时 bare `fetch --depth 1 --filter=blob:none` + `ls-tree -r`；`remoteFiles===0` 算「两边都空」，用 `--force-with-lease` 覆盖空分支 |
| 拉取整份覆盖 settings，改完没推送就拉取 → 被静默盖回 | 覆盖前比对（占位符归一 + CRLF 拉平 + `our-free-model.json` 三个时间戳置 0），不同就写 `config-sync-overwrite.json` 并提示 |
| 同步后**新建会话直接失败**：`failed to create session … corrupt Zstandard session log: invalid frame magic at byte 186` | DSH 写的首帧**带 4 字节 content checksum**（帧头描述符 FHD 的 bit2），二分找「最小可解前缀」时解压器对**去掉 checksum 的前缀**照样成功 → 帧尾算短 4 字节；写回把旧 checksum 留成垃圾，DSH 读第二帧就撞上。改成：按 FHD bit2 补 4 字节 → 再以「下一帧帧头」校正 → 写回前自检（首帧 cwd 生效 + 新首帧末尾必须是下一帧帧头），不过不落盘；遇到历史残留尾巴顺手丢掉自愈 |

## 性能（0.3.54）：零行为变化的三处提速

三处都只改「怎么算」，不改「算什么」：落到仓库的文件、提交内容、错误判定与 0.3.53 逐字节一致，只是更快。数据来自同规模假仓库（50889 文件 / 416MB，五万级）与真实 Gitee：

| 环节 | 改之前 | 改之后 | 为什么 |
|---|---|---|---|
| capture 判断「文件要不要重写」 | 每个文件算两次 `Get-FileHash`（源 + 仓库）：单文件 1.2ms → 5 万文件 ≈ **120s** | 两次 `Get-ChildItem` 各拿一次 `FileInfo`（Length / LastWriteTimeUtc 随枚举已读好）+ 纯内存字典比对 **3.9s**；只有 size 或 mtime 不一致才算哈希 | 逐文件 `Test-Path` / `Get-Item` 反而**更慢**（实测 37.8s，每次 cmdlet 调用约 0.7ms），批量枚举才是正路 |
| 推送前扫「历史里的大文件」 | 每次 push 都跑 `git ls-tree -r -l HEAD`：五万文件仓库 **20–23s**，而它查的历史几乎不变 | 按提交缓存到 `.dsh\sync-history-scan.json`（`{commit, oversized, at}`）：commit 相同、或是当前 HEAD 的祖先就跳过；只有首次、被远端拒绝、或显式 `-ScanHistory` 才全量扫 | 新增文件已经由索引预检挡住；历史扫描只负责「老提交里已经躺着一个大文件」这条死路 |
| 拉取 | `git pull --ff-only` 内部是 fetch + merge，而脚本前面已经 fetch 过 → **两次网络往返**（SSH 握手实测 ≈0.95s/次） | 先 `fetch origin --prune`，再 `merge --ff-only origin/<branch>` → **一次往返**；`merge --ff-only` 只认快进，本地有改动/非快进照样失败，语义完全不变 | 带冲突清单进来的那一轮会跳过一次 fetch，此时先补一次，保证 merge 用的是最新 refs |

两个新开关都在 `sync.ps1` 上，**默认关**，默认路径的行为与 0.3.53 相同：

- `-DeepVerify`：透传 `capture.ps1`，无视 size/mtime 快筛，**每个文件都算哈希**。怀疑出现「大小和时间都没变、内容却变了」的漂移时用（代价是回到 1.2ms/文件）。
- `-ScanHistory`：无视历史扫描缓存，**这次一定全量扫** `ls-tree -r -l HEAD`。换了远端、怀疑缓存过期、或想手工复核时用。

```powershell
pwsh -File sync.ps1 push -DeepVerify
pwsh -File sync.ps1 push -ScanHistory
```

输出上看得出来走了哪条路：`文件比较（快筛）：比对 N 个，深哈希 M 个` / `文件比较（深校验开）：比对 N 个，深哈希 N 个`。

## 自检

- `node tools\selftest.mjs <仓库路径>`：假 ctx 拉起宿主半身，打 status、auto、scope 等路由，断言 JSON 结构与落地文件。**必须显式传仓库路径**。
- `node tools\clientcheck.mjs`：假 `__ModuleLoader__` + react 替身跑客户端半身，断言模块能加载、`apply()` 三处注册成功、`inject` 返回回收函数、组件在无数据下渲染不抛。
- `pwsh -File tools\pack-plugin.ps1`：打包并把 sha256 回填 `version.json`。**必须用 PowerShell 7**（脚本是无 BOM UTF-8，5.1 按 GBK 读会把中文认错）。

## 实测记录

| 日期 | 版本 | 要点 |
|---|---|---|
| 2026-11-25 | 0.4.06 | 点 × 立即执行：后端新增常驻窗口监视（250ms 采样可见窗口数，最小化不算），曾经有窗口且连续 4 拍归零即认定关窗 → 当场判 drift、排队 watcher、确有活才强杀残留进程；不依赖前端信标。post-exit wait 归零 3 拍即开工，过期 watcher 让位收紧到「超 5 分钟且从未见过窗口」 |
| 2026-11-25 | 0.4.05 | 点 × 有待推送却没推送：根因前端信标未送达，改后端定时复查预排 watcher（不关 DSH），关窗后自动执行；前端信标降为双保险 |
| 2026-11-25 | 0.4.04 | 修复点 × 关闭后 push watcher 被无窗口孤儿进程卡在 wait 不执行：过期判定改看有无遗留前台窗口，立即清锁让位 |
| 2026-11-25 | 0.4.03 | 重新打包发布：代码与 0.4.02 一致，仅版本与发布元数据更新到 0.4.03 |
| 2026-11-25 | 0.4.02 | 修复 npm 兜底下载的版本规范化：0.4.01 被 npm semver 规范化成 0.4.1，拼 tarball 时去前导零，否则 404 |
| 2026-11-25 | 0.4.01 | 自动同步仅在主动关闭 DSH 窗口（×）时触发：scheduleAutoStart 只做 drift 状态更新，handleSettings 只排队不退出，只有 × 关闭/页面卸载走 shouldCloseDsh: true 真正关闭 DSH |
| 2026-11-25 | 0.3.99 | 勾选自动同步开关即时触发判断（核心逻辑抽离为 checkAndQueueAutoSync，scheduleAutoStart/triggerAutoSyncOnClose/handleSettings 三路复用，开关变更即时排队，手动模式跳过确认框） |
| 2026-11-25 | 0.3.98 | 默认工作区会话纳入同步（稳定名 --default-workspace--，apply 按本机 defaultWorkspaceId 重编码目录/cwd/projcache 并合并 sessionIds），资料仍各机独立 |
| 2026-11-25 | 0.3.97 | 点 × 检测到待拉取/待推送后，从独立进程主动强制退出 DSH 进程族（detached taskkill /F），watcher 立刻执行，不再干等残留进程 |
| 2026-11-24 | 0.3.96 | 页面卸载信标（pagehide→sendBeacon /auto-exit）取代失效的 Electron 关窗钩子，fast 判据（本地 tracking ref、不 fetch）毫秒级排队 watcher，真正修好「点 × 不触发」 |
| 2026-11-24 | 0.3.95 | 修复 post-exit.ps1 丢 UTF-8 BOM 致 PS5.1 按 GBK 解码、55 处语法错启动即崩：三处执行体补回 BOM，selftest 加全量 ps1 BOM 断言防回归 |
| 2026-11-24 | 0.3.94 | 修复跨重启僵死 watcher 占锁：锁记 watchPid、复用前查僵死、旧锁杀掉重排；post-exit wait 段过期 watcher 自清让位；解决「勾了开关点 × 仍不触发」 |
| 2026-11-24 | 0.3.93 | 点 × 关闭 DSH 时立即判一次自动拉取/推送并排队 watcher，不再等 2 分钟复查窗口；autoRestart 语义统一为 !== false |
| 2026-11-24 | 0.3.92 | 远端「未提交」纳入本机待同步数据（pending），刷新按钮真正触发 git fetch；解决「远端数字一直是 0」 |
| 2026-11-24 | 0.3.91 | 设置-通用-配置同步摘要行展开时先 fetch 再刷新远端信息（不再陈旧、每 30 秒自动刷新）；四个生成脚本按钮换成「立即拉取/推送（会关闭 DSH）」两个，走自动同步同一队列 |
| 2026-11-24 | 0.3.90 | 顶部跳转按钮跟随当前位置高亮；待办去掉「本机数据」字眼、可展开看具体会话记录名与本机 profile |
| 2026-11-24 | 0.3.89 | 插件更新卡新增「npm 下载路径」；npm 双源（镜像+官方）兜底下载，仍按权威 sha256 校验 |
| 2026-11-23 | 0.3.86 | 「本机数据」挪进概览-待办，按同步内容的 12 组口径分类统计，会话样本显示会话标题而非 session id |
| 2026-11-23 | 0.3.85 | 去掉工作区显示卡片编辑态的强调色说明条，编辑与否只看标题行「修改」/「完成」按钮 |
| 2026-11-23 | 0.3.84 | 工作区显示卡片改成整卡一个「修改」按钮；会话行自带开关、加底色与分隔线，隐藏态删除线 |
| 2026-11-23 | 0.3.83 | 工作区显示卡片再折叠空会话与 Mnemon 空闲审查父容器；本机默认视图 99 → 10 条 |
| 2026-11-23 | 0.3.82 | 工作区显示卡片默认折叠智能体会话；隐藏/显示改走 workspaceRegistry，切完即时生效（不再需要重启） |
| 2026-11-21 | 0.3.75 | 隐藏/归档的工作区跨机同步（workspace-archives.v1.json 纳入 settings），B 机拉取后不再显示已隐藏的工作区与会话 |
| 2026-11-19 | 0.3.69 | 跨机搬运 billion-context 压缩状态（bili-state.mjs）；同步清单新增 plugin-missing / context-state 两类提示 |
| 2026-11-19 | 0.3.68 | 会话投影缓存守卫，治 agent-busy 建会话失败 |
| 2026-11-19 | 0.3.67 | 会话日志 seq 对账护栏（跨机写同一会话按 seq 求并集，不再整文件覆盖）；.gitattributes 钉 binary；capture hoist |
| 2026-11-19 | 0.3.66 | .gitattributes 消除 LF/CRLF 警告 |
| 2026-11-18 | 0.3.65 | 刷新按钮反馈（文字变「刷新中…」） |
| 2026-11-18 | 0.3.64 | 还原备份修复（写回原位）+ 失败原因集中展示 + 6 分钟自动关窗 |
| 2026-11-18 | 0.3.63 | 推送提速：Get-RelPath 快 10 倍 |
| 2026-11-18 | 0.3.62 | 拉取提速：341s → 109s（3.1×） |
| 2026-11-15 | 0.3.54 | 三处提速（快筛/历史缓存/单次 fetch），行为不变 |
| 2026-11-14 | — | 两台机器从零跑通（隔离环境）；会话日志首帧 4 字节残留修复 |
| 2026-11-11 | — | 单机隔离环境全链路验证（装插件 → 拉取 → 推送 → 还原） |

详细测试数据见对应版本的 Release Notes。
